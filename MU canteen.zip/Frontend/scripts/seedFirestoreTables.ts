import { initializeApp } from 'firebase/app';
import { getAuth, signInWithEmailAndPassword, signInAnonymously } from 'firebase/auth';
import { getFirestore, collection, doc, setDoc, getDocs } from 'firebase/firestore';

const firebaseConfig = {
  apiKey: "AIzaSyBID6aEpDYUdZPW-Dq1lhOaMLtIbeo-Rng",
  authDomain: "mu-canteen-b895a.firebaseapp.com",
  projectId: "mu-canteen-b895a",
  storageBucket: "mu-canteen-b895a.firebasestorage.app",
  messagingSenderId: "231604059707",
  appId: "1:231604059707:android:cabf8e38c301d1a3fc261e"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);

async function seed() {
  console.log('--- Authenticating with Firebase ---');
  try {
    await signInWithEmailAndPassword(auth, 'admin@marwadiuniversity.ac.in', 'password123');
    console.log('Signed in as admin');
  } catch (authErr) {
    console.log('Admin sign in fallback, trying student or anonymous...', authErr);
    try {
      await signInWithEmailAndPassword(auth, 'student1@marwadiuniversity.ac.in', 'password123');
      console.log('Signed in as student');
    } catch {
      await signInAnonymously(auth);
      console.log('Signed in anonymously');
    }
  }

  console.log('--- Seeding Firestore for MU Canteen ---');

  // 1. Seed payments_history
  const samplePayments = [
    {
      id: 'pay_init_1',
      payment_id: 'pay_init_1',
      order_id: 'ord_init_1',
      user_id: 'usr_student_1',
      canteen_id: 'canteen_main_1',
      payment_mode: 'online',
      price: 70,
      payment_status: 'PAID_ONLINE',
      timestamp: new Date().toISOString(),
    },
    {
      id: 'pay_init_2',
      payment_id: 'pay_init_2',
      order_id: 'ord_init_2',
      user_id: 'usr_student_2',
      canteen_id: 'canteen_main_2',
      payment_mode: 'cash',
      price: 110,
      payment_status: 'CASH_RECEIVED',
      timestamp: new Date().toISOString(),
    },
    {
      id: 'pay_init_3',
      payment_id: 'pay_init_3',
      order_id: 'ord_init_3',
      user_id: 'usr_student_1',
      canteen_id: 'canteen_law_1',
      payment_mode: 'online',
      price: 85,
      payment_status: 'PAID_ONLINE',
      timestamp: new Date().toISOString(),
    }
  ];

  for (const pay of samplePayments) {
    console.log(`Writing payment ${pay.id} to payments_history...`);
    await setDoc(doc(db, 'payments_history', pay.id), pay);
    await setDoc(doc(db, 'payment_history', pay.id), pay);
  }

  // 2. Seed Revenue
  const todayStr = new Date().toISOString().split('T')[0];
  const sampleRevenues = [
    {
      id: `rev_canteen_main_1_${todayStr}`,
      revenue_id: `rev_canteen_main_1_${todayStr}`,
      canteen_id: 'canteen_main_1',
      date: todayStr,
      total_orders: 14,
      total_revenue: 1240,
      updated_at: new Date().toISOString(),
    },
    {
      id: `rev_canteen_main_2_${todayStr}`,
      revenue_id: `rev_canteen_main_2_${todayStr}`,
      canteen_id: 'canteen_main_2',
      date: todayStr,
      total_orders: 9,
      total_revenue: 890,
      updated_at: new Date().toISOString(),
    },
    {
      id: `rev_canteen_law_1_${todayStr}`,
      revenue_id: `rev_canteen_law_1_${todayStr}`,
      canteen_id: 'canteen_law_1',
      date: todayStr,
      total_orders: 7,
      total_revenue: 630,
      updated_at: new Date().toISOString(),
    },
    {
      id: `rev_canteen_faculty_3_${todayStr}`,
      revenue_id: `rev_canteen_faculty_3_${todayStr}`,
      canteen_id: 'canteen_faculty_3',
      date: todayStr,
      total_orders: 5,
      total_revenue: 450,
      updated_at: new Date().toISOString(),
    }
  ];

  for (const rev of sampleRevenues) {
    console.log(`Writing revenue ${rev.id} to Revenue...`);
    await setDoc(doc(db, 'Revenue', rev.id), rev);
    await setDoc(doc(db, 'revenue', rev.id), rev);
  }

  console.log('Checking documents in payments_history...');
  const paySnap = await getDocs(collection(db, 'payments_history'));
  console.log(`payments_history count: ${paySnap.size}`);

  console.log('Checking documents in Revenue...');
  const revSnap = await getDocs(collection(db, 'Revenue'));
  console.log(`Revenue count: ${revSnap.size}`);

  console.log('Seeding completed successfully!');
  process.exit(0);
}

seed().catch((err) => {
  console.error('Seed error:', err);
  process.exit(1);
});
