import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { useAuth } from './AuthContext';
import {
  listenUserNotifications,
  markNotificationRead,
  markAllNotificationsRead,
  getUserNotificationSettings,
  updateUserNotificationSettings,
  checkAndExpireOrders,
} from '../services/firestoreService';
import type { AppNotification, NotificationSettings } from '../models/types';

interface NotificationContextType {
  notifications: AppNotification[];
  unreadCount: number;
  settings: NotificationSettings | null;
  updateSettings: (key: keyof Omit<NotificationSettings, 'user_id'>, value: boolean) => Promise<void>;
  markAsRead: (id: string) => Promise<void>;
  markAllRead: () => Promise<void>;
}

const NotificationContext = createContext<NotificationContextType>({} as NotificationContextType);

export const NotificationProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user } = useAuth();
  const [notifications, setNotifications] = useState<AppNotification[]>([]);
  const [settings, setSettings] = useState<NotificationSettings | null>(null);

  // Request browser notification permissions on mount if in web environment
  useEffect(() => {
    if (typeof window !== 'undefined' && 'Notification' in window && Notification.permission === 'default') {
      Notification.requestPermission().catch(() => {});
    }
  }, []);

  // Periodic check for 2-min warning and auto-expiring orders
  useEffect(() => {
    const timer = setInterval(() => {
      checkAndExpireOrders().catch(() => {});
    }, 10000);
    return () => clearInterval(timer);
  }, []);

  // Listen to Firestore notifications in real time
  useEffect(() => {
    if (!user?.user_id) {
      setNotifications([]);
      return;
    }

    const unsubscribe = listenUserNotifications(user.user_id, (notifs: AppNotification[]) => {
      setNotifications(notifs);
    });

    return () => unsubscribe();
  }, [user?.user_id]);

  // Load notification settings
  useEffect(() => {
    if (!user?.user_id) {
      setSettings(null);
      return;
    }

    getUserNotificationSettings(user.user_id).then((s: NotificationSettings) => {
      setSettings(s);
    });
  }, [user?.user_id]);

  const unreadCount = notifications.filter((n) => !n.is_read).length;

  const updateSettings = useCallback(
    async (key: keyof Omit<NotificationSettings, 'user_id'>, value: boolean) => {
      if (!user?.user_id) return;

      const defaultSettings: NotificationSettings = {
        user_id: user.user_id,
        order_placed: true,
        order_accepted: true,
        order_preparing: true,
        order_ready: true,
        pickup_warning: true,
        pickup_failed: true,
        order_declined: true,
      };

      const updated: NotificationSettings = {
        ...(settings || defaultSettings),
        user_id: user.user_id,
        [key]: value,
      };

      setSettings(updated);
      await updateUserNotificationSettings(user.user_id, updated);
    },
    [user?.user_id, settings]
  );

  const markAsRead = useCallback(
    async (id: string) => {
      setNotifications((prev) =>
        prev.map((n) => (n.notification_id === id ? { ...n, is_read: true } : n))
      );
      await markNotificationRead(id);
    },
    []
  );

  const markAllRead = useCallback(async () => {
    if (!user?.user_id) return;
    setNotifications((prev) => prev.map((n) => ({ ...n, is_read: true })));
    await markAllNotificationsRead(user.user_id);
  }, [user?.user_id]);

  return (
    <NotificationContext.Provider
      value={{ notifications, unreadCount, settings, updateSettings, markAsRead, markAllRead }}
    >
      {children}
    </NotificationContext.Provider>
  );
};

export const useNotifications = () => useContext(NotificationContext);
