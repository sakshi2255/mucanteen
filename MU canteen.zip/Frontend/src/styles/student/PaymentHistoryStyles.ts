import { StyleSheet } from 'react-native';
import { colors, typography, spacing, borderRadius, shadows } from '../../config/theme';

export const styles = StyleSheet.create({
  safeArea: { flex: 1, backgroundColor: '#FFFFFF' },
  header: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between',
    paddingHorizontal: spacing.lg, paddingVertical: spacing.md, borderBottomWidth: 1, borderBottomColor: colors.borderLight,
  },
  backBtn: { padding: 4 },
  headerTitle: { fontSize: 16, fontWeight: typography.fontWeights.heavy, color: colors.textPrimary },
  container: { flex: 1, backgroundColor: '#F8FAFC' },
  statsCard: { backgroundColor: colors.primaryDark, margin: spacing.lg, padding: spacing.lg, borderRadius: borderRadius.lg, ...shadows.md },
  statsLabel: { color: 'rgba(255, 255, 255, 0.8)', fontSize: 12, fontWeight: '600', marginBottom: 4 },
  statsValue: { color: '#FFFFFF', fontSize: 28, fontWeight: typography.fontWeights.heavy },
  listContent: { paddingHorizontal: spacing.lg, paddingBottom: spacing.xl },
  paymentCard: { backgroundColor: '#FFFFFF', padding: spacing.md, borderRadius: borderRadius.md, borderWidth: 1, borderColor: colors.borderLight, marginBottom: spacing.md, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', ...shadows.sm },
  iconBox: { width: 40, height: 40, borderRadius: 20, backgroundColor: colors.backgroundSoft, justifyContent: 'center', alignItems: 'center', marginRight: spacing.md },
  detailsCol: { flex: 1 },
  orderId: { fontSize: 12, color: colors.textSecondary, marginBottom: 2 },
  dateText: { fontSize: 11, color: colors.textMuted },
  priceCol: { alignItems: 'flex-end' },
  priceText: { fontSize: 15, fontWeight: typography.fontWeights.heavy, color: colors.primaryDark },
  statusPill: { marginTop: 4, paddingHorizontal: 6, paddingVertical: 2, borderRadius: 4 },
  statusText: { fontSize: 9, fontWeight: 'bold' },
});