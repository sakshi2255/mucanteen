import { StyleSheet } from 'react-native';
import { colors, typography, spacing, borderRadius, shadows } from '../../config/theme';

export const styles = StyleSheet.create({
  safeArea: { flex: 1, backgroundColor: '#FFFFFF' },
  container: { flex: 1, backgroundColor: '#F8FAFC' },
  scrollContent: { paddingBottom: 120 },
  searchContainer: {
    flexDirection: 'row', alignItems: 'center', backgroundColor: '#FFFFFF',
    marginHorizontal: spacing.lg, marginVertical: spacing.md, paddingHorizontal: spacing.lg,
    borderRadius: borderRadius.lg, height: 54, ...shadows.md,
  },
  searchIcon: { marginRight: spacing.md },
  searchInput: { flex: 1, fontSize: 16, fontWeight: '500', color: colors.textPrimary },
  filterSection: { backgroundColor: '#F8FAFC', paddingVertical: spacing.sm, borderBottomWidth: 1, borderBottomColor: colors.borderLight },
  filterScroll: { paddingHorizontal: spacing.lg, gap: spacing.sm },
  filterChip: {
    flexDirection: 'row', alignItems: 'center', paddingHorizontal: 16, paddingVertical: 10,
    borderRadius: borderRadius.full, backgroundColor: '#FFFFFF', borderWidth: 1, borderColor: colors.borderLight, gap: 6, ...shadows.sm,
  },
  filterChipActive: { backgroundColor: colors.primaryDark, borderColor: colors.primaryDark },
  filterChipText: { fontSize: 14, color: colors.textSecondary, fontWeight: typography.fontWeights.bold },
  filterChipTextActive: { color: '#FFFFFF' },
  sectionHeader: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingHorizontal: spacing.lg, marginTop: spacing.lg, marginBottom: spacing.md },
  sectionTitle: { fontSize: 15, fontWeight: typography.fontWeights.heavy, color: colors.textPrimary, letterSpacing: 1 },
  canteenCountText: { fontSize: 13, color: colors.primaryDark, fontWeight: typography.fontWeights.heavy },
  
  // 2x2 Grid Styles
  gridContainer: { 
    flexDirection: 'row', 
    flexWrap: 'wrap', 
    paddingHorizontal: spacing.lg, 
    justifyContent: 'space-between' 
  },
  gridColumn: { 
    width: '48%', 
    marginBottom: spacing.md 
  },
  
  emptyContainer: { padding: spacing.xl, alignItems: 'center', justifyContent: 'center', marginTop: spacing.xl, width: '100%' },
  emptyTitle: { fontSize: 18, fontWeight: typography.fontWeights.heavy, color: colors.textPrimary, marginTop: spacing.md },
  emptySubtitle: { fontSize: 14, color: colors.textSecondary, marginTop: 6 },
  stickyCartBar: {
    position: 'absolute', bottom: spacing.lg, left: spacing.lg, right: spacing.lg,
    backgroundColor: colors.primaryDark, borderRadius: borderRadius.lg, paddingHorizontal: spacing.lg, paddingVertical: spacing.md,
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', ...shadows.lg,
  },
  cartBarInfo: { flexDirection: 'row', alignItems: 'center', gap: spacing.md },
  cartCountBadge: { width: 32, height: 32, borderRadius: 16, backgroundColor: colors.accentOrange, justifyContent: 'center', alignItems: 'center' },
  cartCountText: { color: '#FFFFFF', fontSize: 14, fontWeight: typography.fontWeights.heavy },
  cartBarTotal: { fontSize: 18, fontWeight: typography.fontWeights.heavy, color: '#FFFFFF' },
  cartBarSubtitle: { fontSize: 12, color: 'rgba(255, 255, 255, 0.8)', fontWeight: '500' },
  cartBarButton: {
    flexDirection: 'row', alignItems: 'center', backgroundColor: colors.accentOrange,
    paddingHorizontal: 16, paddingVertical: 12, borderRadius: borderRadius.md, gap: 6,
  },
  cartBarButtonText: { color: '#FFFFFF', fontSize: 14, fontWeight: typography.fontWeights.heavy },
});