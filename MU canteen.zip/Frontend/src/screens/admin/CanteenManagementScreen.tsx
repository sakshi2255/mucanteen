import React, { useState, useEffect } from 'react';
import { View, Text, FlatList, TouchableOpacity, Switch, Alert, Modal, TextInput, ScrollView } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { ArrowLeft, MapPin, Clock, Edit2, Trash2, X } from 'lucide-react-native';
import { doc, updateDoc } from 'firebase/firestore';
import { db } from '../../config/firebaseConfig';
import { colors } from '../../config/theme';
import { useAuth } from '../../context/AuthContext';
import { listenCanteens, toggleCanteenStatus } from '../../services/firestoreService';
import { styles } from '../../styles/admin/CanteenManagementStyles';
import type { Canteen } from '../../models/types';

interface CanteenManagementScreenProps { navigation: any; }

export const CanteenManagementScreen: React.FC<CanteenManagementScreenProps> = ({ navigation }) => {
  const { user } = useAuth();
  const [canteens, setCanteens] = useState<Canteen[]>([]);
  
  const [modalVisible, setModalVisible] = useState(false);
  const [editingCanteen, setEditingCanteen] = useState<Canteen | null>(null);
  const [formData, setFormData] = useState({
    name: '',
    operating_hours: '',
    canteen_type: 'common',
    acceptance_mode: 'manual'
  });

  useEffect(() => {
    // listenCanteens now needs to be filtered to exclude soft-deleted (is_active: false)
    const unsub = listenCanteens((list) => {
      setCanteens(list.filter(c => c.is_active !== false)); 
    });
    return unsub;
  }, []);

  const handleToggle = async (canteenId: string, currentOpen: boolean) => {
    await toggleCanteenStatus(canteenId, !currentOpen, { id: user?.user_id || 'admin', name: user?.name || 'Administrator', role: 'admin' });
  };

  const openEditModal = (canteen: Canteen) => {
    setEditingCanteen(canteen);
    setFormData({
      name: canteen.name,
      operating_hours: canteen.operating_hours || '',
      canteen_type: canteen.canteen_type || 'common',
      acceptance_mode: canteen.acceptance_mode || 'manual'
    });
    setModalVisible(true);
  };

  const handleSaveCanteen = async () => {
    if (!editingCanteen) return;
    try {
      const canteenRef = doc(db, 'canteens', editingCanteen.canteen_id);
      await updateDoc(canteenRef, {
        name: formData.name,
        operating_hours: formData.operating_hours,
        canteen_type: formData.canteen_type,
        acceptance_mode: formData.acceptance_mode,
        updated_at: new Date().toISOString()
      });
      setModalVisible(false);
    } catch (error) {
      Alert.alert('Error', 'Failed to update canteen details.');
    }
  };

  const handleDelete = (canteen: Canteen) => {
    Alert.alert(
      "Deactivate Canteen",
      `Are you sure you want to deactivate ${canteen.name}? It will be soft-deleted and removed from the student view.`,
      [
        { text: "Cancel", style: "cancel" },
        { 
          text: "Deactivate", 
          style: "destructive",
          onPress: async () => {
            try {
              // SOFT DELETE
              await updateDoc(doc(db, 'canteens', canteen.canteen_id), { is_active: false });
            } catch (error) {
              Alert.alert('Error', 'Failed to deactivate canteen.');
            }
          }
        }
      ]
    );
  };

  return (
    <SafeAreaView style={styles.safeArea}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backBtn}><ArrowLeft size={22} color={colors.textPrimary} /></TouchableOpacity>
        <Text style={styles.headerTitle}>Campus Canteens Management</Text>
        <View style={{ width: 22 }} />
      </View>

      <FlatList
        data={canteens}
        keyExtractor={(item) => item.canteen_id}
        contentContainerStyle={styles.listContent}
        showsVerticalScrollIndicator={false}
        renderItem={({ item }) => (
          <View style={styles.canteenCard}>
            <View style={styles.cardHeader}>
              <View style={styles.titleArea}>
                <Text style={styles.name}>{item.name}</Text>
                <View style={styles.metaRow}>
                  <MapPin size={12} color={colors.textSecondary} />
                  <Text style={styles.metaText}>Floor {item.floor === 0 ? 'Ground' : item.floor} • {item.building_id}</Text>
                </View>
                <View style={styles.metaRow}>
                  <Clock size={12} color={colors.textSecondary} />
                  <Text style={styles.metaText}>{item.operating_hours}</Text>
                </View>
              </View>

              <View style={styles.toggleCol}>
                <Text style={[styles.statusText, item.is_open ? styles.openText : styles.closedText]}>{item.is_open ? 'OPEN' : 'CLOSED'}</Text>
                <Switch value={item.is_open} onValueChange={() => handleToggle(item.canteen_id, item.is_open)} trackColor={{ false: '#FECACA', true: '#A7F3D0' }} thumbColor={item.is_open ? colors.accentGreen : '#EF4444'} />
              </View>
            </View>

            <View style={styles.footerRow}>
              <Text style={styles.typeTag}>Type: {item.canteen_type.replace('_', ' ').toUpperCase()}</Text>
              <Text style={styles.modeTag}>Mode: {item.acceptance_mode.toUpperCase()}</Text>
            </View>

            <View style={styles.actionRow}>
              <TouchableOpacity style={styles.actionBtn} onPress={() => openEditModal(item)}>
                <Edit2 size={14} color={colors.primaryDark} />
                <Text style={styles.editBtnText}>Edit</Text>
              </TouchableOpacity>
              
              <TouchableOpacity style={styles.actionBtn} onPress={() => handleDelete(item)}>
                <Trash2 size={14} color={colors.accentRed} />
                <Text style={styles.deleteBtnText}>Deactivate</Text>
              </TouchableOpacity>
            </View>
          </View>
        )}
      />

      {/* Edit Canteen Modal */}
      <Modal visible={modalVisible} animationType="fade" transparent={true}>
        <View style={styles.modalOverlay}>
          <View style={styles.modalContainer}>
            <View style={styles.modalHeaderRow}>
              <Text style={styles.modalTitle}>Edit Canteen</Text>
              <TouchableOpacity onPress={() => setModalVisible(false)}><X size={24} color={colors.textSecondary} /></TouchableOpacity>
            </View>

            <Text style={styles.inputLabel}>Canteen Name</Text>
            <TextInput style={styles.inputField} value={formData.name} onChangeText={t => setFormData({...formData, name: t})} />

            <Text style={styles.inputLabel}>Operating Hours</Text>
            <TextInput style={styles.inputField} value={formData.operating_hours} onChangeText={t => setFormData({...formData, operating_hours: t})} />

            <Text style={styles.inputLabel}>Access Type</Text>
            <View style={styles.radioGroup}>
              <TouchableOpacity style={[styles.radioBtn, formData.canteen_type === 'common' && styles.radioBtnActive]} onPress={() => setFormData({...formData, canteen_type: 'common'})}>
                <Text style={[styles.radioText, formData.canteen_type === 'common' && styles.radioTextActive]}>Common</Text>
              </TouchableOpacity>
              <TouchableOpacity style={[styles.radioBtn, formData.canteen_type === 'faculty_only' && styles.radioBtnActive]} onPress={() => setFormData({...formData, canteen_type: 'faculty_only'})}>
                <Text style={[styles.radioText, formData.canteen_type === 'faculty_only' && styles.radioTextActive]}>Faculty Only</Text>
              </TouchableOpacity>
            </View>

            <Text style={styles.inputLabel}>Order Acceptance</Text>
            <View style={styles.radioGroup}>
              <TouchableOpacity style={[styles.radioBtn, formData.acceptance_mode === 'manual' && styles.radioBtnActive]} onPress={() => setFormData({...formData, acceptance_mode: 'manual'})}>
                <Text style={[styles.radioText, formData.acceptance_mode === 'manual' && styles.radioTextActive]}>Manual</Text>
              </TouchableOpacity>
              <TouchableOpacity style={[styles.radioBtn, formData.acceptance_mode === 'auto' && styles.radioBtnActive]} onPress={() => setFormData({...formData, acceptance_mode: 'auto'})}>
                <Text style={[styles.radioText, formData.acceptance_mode === 'auto' && styles.radioTextActive]}>Auto-Accept</Text>
              </TouchableOpacity>
            </View>

            <TouchableOpacity style={styles.saveBtn} onPress={handleSaveCanteen}>
              <Text style={styles.saveBtnText}>Save Changes</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
};