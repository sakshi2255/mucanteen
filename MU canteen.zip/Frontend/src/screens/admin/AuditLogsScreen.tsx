import React, { useState, useEffect } from 'react';
import { View, Text, FlatList, TouchableOpacity, Modal } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { ArrowLeft, Shield, Clock, ChevronDown } from 'lucide-react-native';
import { colors } from '../../config/theme';
import { fetchAuditLogs } from '../../services/firestoreService';
import { styles } from '../../styles/admin/AuditLogsStyles';
import type { AuditLog } from '../../models/types';

interface AuditLogsScreenProps { navigation: any; }

const FILTER_OPTIONS = [
  { id: 'all', label: 'All Activities' },
  { id: 'order', label: 'Orders' },
  { id: 'menuItem', label: 'Menu Items' },
  { id: 'canteen', label: 'Canteens' },
  { id: 'user', label: 'Users' }
];

export const AuditLogsScreen: React.FC<AuditLogsScreenProps> = ({ navigation }) => {
  const [logs, setLogs] = useState<AuditLog[]>([]);
  const [filterType, setFilterType] = useState<string>('all');
  const [showDropdown, setShowDropdown] = useState(false);

  useEffect(() => { loadLogs(); }, []);

  const loadLogs = async () => {
    const list = await fetchAuditLogs();
    setLogs(list);
  };

  const filteredLogs = logs.filter((l) => {
    if (filterType === 'all') return true;
    return l.entity_type?.toLowerCase() === filterType.toLowerCase();
  });

  const selectedFilterLabel = FILTER_OPTIONS.find((f) => f.id === filterType)?.label || 'All Activities';

  return (
    <SafeAreaView style={styles.safeArea}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backBtn}>
          <ArrowLeft size={22} color={colors.textPrimary} />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Campus Audit Trail</Text>
        <TouchableOpacity onPress={loadLogs} style={styles.backBtn}>
          <Clock size={18} color={colors.primary} />
        </TouchableOpacity>
      </View>

      <View style={styles.dropdownContainer}>
        <TouchableOpacity style={styles.dropdownBtn} onPress={() => setShowDropdown(true)}>
          <Text style={styles.dropdownText}>
            Filter: {selectedFilterLabel}
          </Text>
          <ChevronDown size={18} color={colors.primary} />
        </TouchableOpacity>
      </View>

      <FlatList
        data={filteredLogs}
        keyExtractor={(item) => item.audit_log_id || Math.random().toString()}
        contentContainerStyle={styles.listContent}
        showsVerticalScrollIndicator={false}
        ListEmptyComponent={
          <View style={styles.emptyContainer}>
            <Shield size={38} color={colors.textMuted} />
            <Text style={styles.emptyTitle}>Audit Log Active</Text>
            <Text style={styles.emptySubtitle}>Actions performed by students, canteen operators, and administrators are recorded immutably here.</Text>
          </View>
        }
        renderItem={({ item }) => (
          <View style={styles.logCard}>
            <View style={styles.logHeader}>
              <View style={styles.actionPill}><Text style={styles.actionText}>{item.action || 'UPDATE'}</Text></View>
              <Text style={styles.timestampText}>{item.timestamp ? new Date(item.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }) : 'Unknown Time'}</Text>
            </View>
            <Text style={styles.descriptionText}>{item.description}</Text>
            <View style={styles.footerRow}>
              <View style={styles.metaCol}>
                <Text style={styles.actorText}>Actor: {item.actor_name_snapshot || 'System'} ({item.actor_role || 'user'})</Text>
                <Text style={styles.entityText}>{item.entity_type ? `${item.entity_type.toUpperCase()} ID: ` : 'ID: '} {item.entity_id ? item.entity_id.slice(-8) : 'N/A'}</Text>
              </View>
            </View>
          </View>
        )}
      />

      <Modal visible={showDropdown} transparent animationType="fade">
        <TouchableOpacity style={styles.modalOverlay} onPress={() => setShowDropdown(false)}>
          <View style={styles.menuContainer}>
            <Text style={styles.menuHeader}>Filter by Entity Type</Text>
            {FILTER_OPTIONS.map((f) => (
              <TouchableOpacity key={f.id} style={styles.menuItem} onPress={() => { setFilterType(f.id); setShowDropdown(false); }}>
                <Text style={[styles.menuItemText, filterType === f.id && styles.menuItemTextActive]}>
                  {f.label}
                </Text>
              </TouchableOpacity>
            ))}
          </View>
        </TouchableOpacity>
      </Modal>
    </SafeAreaView>
  );
};
