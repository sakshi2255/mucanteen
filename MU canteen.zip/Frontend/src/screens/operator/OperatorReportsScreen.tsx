import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { ArrowLeft } from 'lucide-react-native';
import { colors } from '../../config/theme';
import { useAuth } from '../../context/AuthContext';
import { listenOperatorOrders, listenRevenueForCanteen } from '../../services/firestoreService';
import { getISTDateString } from '../../services/tokenService';
import type { Order, Revenue } from '../../models/types';
import { styles } from '../../styles/operator/OperatorReportsStyles';

interface OperatorReportsScreenProps {
  navigation: any;
}

export const OperatorReportsScreen: React.FC<OperatorReportsScreenProps> = ({ navigation }) => {
  const { user } = useAuth();
  const assignedCanteenId = user?.assigned_canteen_ids?.[0] || 'canteen_main_1';
  const todayStr = getISTDateString();

  const [orders, setOrders] = useState<Order[]>([]);
  const [revenues, setRevenues] = useState<Revenue[]>([]);

  useEffect(() => {
    const unsubOrders = listenOperatorOrders(assignedCanteenId, (list) => {
      setOrders(list);
    });
    const unsubRevenue = listenRevenueForCanteen(assignedCanteenId, (revs) => {
      setRevenues(revs);
    });
    return () => {
      unsubOrders();
      unsubRevenue();
    };
  }, [assignedCanteenId]);

  const todayRevDoc = revenues.find((r) => r.date === todayStr);

  const completed = orders.filter((o) => o.order_status === 'picked_up');
  const active = orders.filter((o) => ['awaiting_acceptance', 'preparing', 'ready_for_pickup'].includes(o.order_status));
  const declined = orders.filter((o) => ['declined', 'cancelled'].includes(o.order_status));
  const liveRevenue = completed.reduce((sum, o) => sum + o.total, 0);

  // Use whichever is higher/more accurate
  const displayRevenue = Math.max(liveRevenue, todayRevDoc?.total_revenue ?? 0);
  const displayOrders = Math.max(completed.length, todayRevDoc?.total_orders ?? 0);

  return (
    <SafeAreaView style={styles.safeArea}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backBtn}>
          <ArrowLeft size={22} color={colors.textPrimary} />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Canteen Daily Report</Text>
        <View style={{ width: 22 }} />
      </View>

      <ScrollView
        style={styles.container}
        contentContainerStyle={styles.content}
        showsVerticalScrollIndicator={false}
      >
        {/* Revenue Card */}
        <View style={styles.revenueCard}>
          <Text style={styles.revenueTitle}>TODAY'S FULFILLED REVENUE</Text>
          <Text style={styles.revenueValue}>₹{displayRevenue}</Text>
          <Text style={styles.revenueSub}>Based on {displayOrders} collected orders</Text>
        </View>

        {/* Firestore Revenue Detail */}
        {todayRevDoc && (
          <View style={styles.firestoreCard}>
            <Text style={styles.firestoreCardTitle}>FIRESTORE REVENUE RECORD · {todayStr}</Text>
            <View style={styles.firestoreRow}>
              <Text style={styles.firestoreLabel}>Total Revenue</Text>
              <Text style={styles.firestoreValue}>₹{todayRevDoc.total_revenue}</Text>
            </View>
            <View style={styles.firestoreRow}>
              <Text style={styles.firestoreLabel}>Total Orders</Text>
              <Text style={styles.firestoreValue}>{todayRevDoc.total_orders}</Text>
            </View>
          </View>
        )}

        {/* Stats Grid */}
        <View style={styles.grid}>
          <View style={styles.statCard}>
            <Text style={styles.statLabel}>Total Received</Text>
            <Text style={styles.statNumber}>{orders.length}</Text>
          </View>

          <View style={styles.statCard}>
            <Text style={styles.statLabel}>Completed</Text>
            <Text style={[styles.statNumber, { color: colors.accentGreen }]}>{completed.length}</Text>
          </View>

          <View style={styles.statCard}>
            <Text style={styles.statLabel}>In Progress</Text>
            <Text style={[styles.statNumber, { color: colors.primaryDark }]}>{active.length}</Text>
          </View>

          <View style={styles.statCard}>
            <Text style={styles.statLabel}>Declined / Cancel</Text>
            <Text style={[styles.statNumber, { color: colors.accentRed }]}>{declined.length}</Text>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
};
