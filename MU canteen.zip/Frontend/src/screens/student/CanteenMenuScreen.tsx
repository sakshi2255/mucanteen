import React, { useState, useEffect, useMemo } from 'react';
import { View, Text, ScrollView, TextInput, TouchableOpacity, Alert } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { ArrowLeft, Search, ShoppingBag, MapPin, Clock, ShieldCheck, Sparkles, Flame, RotateCcw } from 'lucide-react-native';
import { colors } from '../../config/theme';
import { FilterChips } from '../../components/common/FilterChips';
import { FoodCard } from '../../components/common/FoodCard';
import { FloatingCategoryModal } from '../../components/common/FloatingCategoryModal';
import { useAuth } from '../../context/AuthContext';
import { useCart } from '../../context/CartContext';
import { listenMenuItems, listenStudentOrders } from '../../services/firestoreService';
import { INITIAL_CATEGORIES, INITIAL_CANTEENS } from '../../services/seedData';
import { styles } from '../../styles/student/CanteenMenuStyles';
import type { Canteen, MenuItem, Order } from '../../models/types';

interface CanteenMenuScreenProps { navigation: any; route?: any; }

export const CanteenMenuScreen: React.FC<CanteenMenuScreenProps> = ({ route, navigation }) => {
  const canteen: Canteen = route?.params?.canteen || INITIAL_CANTEENS[0];
  const { user } = useAuth();
  const { items: cartItems, subtotal, itemCount, addToCart, removeFromCart, reorderItems } = useCart();
  const [menuItems, setMenuItems] = useState<MenuItem[]>([]);
  const [pastOrders, setPastOrders] = useState<Order[]>([]);
  const [search, setSearch] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [pureVegOnly, setPureVegOnly] = useState(false);
  const [availableNowOnly, setAvailableNowOnly] = useState(false);
  const [maxPrice, setMaxPrice] = useState<number | null>(null);
  const [modalVisible, setModalVisible] = useState(false);

  useEffect(() => {
    const unsubMenu = listenMenuItems(canteen.canteen_id, (items) => setMenuItems(items));
    let unsubOrders = () => {};
    if (user?.user_id) {
      unsubOrders = listenStudentOrders(user.user_id, (orders) => {
        setPastOrders(orders.filter((o) => o.canteen_id === canteen.canteen_id));
      });
    }
    return () => { unsubMenu(); unsubOrders(); };
  }, [canteen.canteen_id, user?.user_id]);

  const categoryItemCounts = useMemo(() => {
    const counts: Record<string, number> = { all: menuItems.length };
    for (const cat of INITIAL_CATEGORIES) {
      if (cat.menu_category_id !== 'all') {
        counts[cat.menu_category_id] = menuItems.filter((i) => i.menu_category_id === cat.menu_category_id).length;
      }
    }
    return counts;
  }, [menuItems]);

  const filteredItems = useMemo(() => {
    return menuItems.filter((item) => {
      if (search.trim()) {
        const q = search.toLowerCase();
        if (!(item.item_name.toLowerCase().includes(q) || item.description.toLowerCase().includes(q))) return false;
      }
      if (selectedCategory !== 'all' && item.menu_category_id !== selectedCategory) return false;
      if (pureVegOnly && !item.is_veg) return false;
      if (availableNowOnly && !item.is_available) return false;
      if (maxPrice !== null && item.price > maxPrice) return false;
      return true;
    });
  }, [menuItems, search, selectedCategory, pureVegOnly, availableNowOnly, maxPrice]);

  const recommendedItems = useMemo(() => filteredItems.filter((i) => i.is_recommended).slice(0, 4), [filteredItems]);
  const getCartQuantity = (itemId: string) => cartItems.find((i) => i.item.menu_item_id === itemId)?.quantity || 0;

  const handleReorder = (order: Order) => {
    if (!order.items_snapshot || order.items_snapshot.length === 0) return;
    reorderItems(order.items_snapshot, canteen.canteen_id, canteen.name, menuItems);
    Alert.alert('Items Added to Cart', `Reordered from token #${order.token_display || order.daily_token_number}.`, [
      { text: 'Keep Browsing', style: 'cancel' },
      { text: 'Go to Cart', onPress: () => navigation.navigate('StudentRoot', { screen: 'Cart' }) }
    ]);
  };

  return (
    <SafeAreaView style={styles.safeArea}>
      <View style={styles.topNav}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backButton}>
          <ArrowLeft size={26} color={colors.textPrimary} />
        </TouchableOpacity>
        <Text style={styles.navTitle} numberOfLines={1}>{canteen.name}</Text>
        <TouchableOpacity style={styles.cartIconWrapper} onPress={() => navigation.navigate('StudentRoot', { screen: 'Cart' })}>
          <ShoppingBag size={22} color={colors.textPrimary} />
          {itemCount > 0 && <View style={styles.cartBadge}><Text style={styles.cartBadgeText}>{itemCount}</Text></View>}
        </TouchableOpacity>
      </View>

      <ScrollView style={styles.container} contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
        <View style={styles.canteenHeaderCard}>
          <View style={styles.canteenTitleRow}>
            <View style={{ flex: 1 }}>
              <Text style={styles.canteenName}>{canteen.name}</Text>
              <Text style={styles.tokenPrefixNote}>Prefix [{canteen.token_prefix || 'A'}] • Floor {canteen.floor}</Text>
            </View>
            <View style={[styles.statusPill, canteen.is_open ? styles.openPill : styles.closedPill]}>
              <Text style={[styles.statusPillText, canteen.is_open ? styles.openText : styles.closedText]}>{canteen.is_open ? 'OPEN' : 'CLOSED'}</Text>
            </View>
          </View>
          <View style={styles.metaRow}>
            <MapPin size={14} color={colors.textSecondary} />
            <Text style={styles.metaText}>Floor {canteen.floor === 0 ? 'Ground' : canteen.floor} • {canteen.building_id.includes('law') ? ' Law Building' : ' Main Academic Building'}</Text>
          </View>
        </View>

        <View style={styles.searchSection}>
          <View style={styles.searchBar}>
            <Search size={18} color={colors.textSecondary} style={{ marginRight: 8 }} />
            <TextInput style={styles.searchInput} placeholder={`Search dishes in ${canteen.name}...`} placeholderTextColor={colors.textMuted} value={search} onChangeText={setSearch} />
          </View>
        </View>

        <FilterChips pureVegOnly={pureVegOnly} onTogglePureVeg={() => setPureVegOnly(!pureVegOnly)} availableNowOnly={availableNowOnly} onToggleAvailableNow={() => setAvailableNowOnly(!availableNowOnly)} selectedBuilding={null} onSelectBuilding={() => {}} maxPrice={maxPrice} onSelectMaxPrice={setMaxPrice} />

        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.categoryScroll}>
          {INITIAL_CATEGORIES.map((cat) => (
            <TouchableOpacity key={cat.menu_category_id} style={[styles.categoryPill, selectedCategory === cat.menu_category_id && styles.activeCategoryPill]} onPress={() => setSelectedCategory(cat.menu_category_id)} activeOpacity={0.7}>
              <Text style={[styles.categoryPillText, selectedCategory === cat.menu_category_id && styles.activeCategoryPillText]}>{cat.category_name}</Text>
            </TouchableOpacity>
          ))}
        </ScrollView>

        <View style={styles.section}>
          <View style={styles.sectionTitleRow}>
            <Flame size={18} color={colors.primary} />
            <Text style={styles.sectionTitle}>All Dishes ({filteredItems.length})</Text>
          </View>

          {filteredItems.length === 0 ? (
            <View style={styles.emptyContainer}>
              <Text style={styles.emptyTitle}>No menu items available</Text>
            </View>
          ) : (
            <View style={styles.gridContainer}>
              {filteredItems.map((item) => (
                <View key={item.menu_item_id} style={styles.gridColumn}>
                  <FoodCard
                    item={item}
                    quantityInCart={getCartQuantity(item.menu_item_id)}
                    onAddToCart={(i) => addToCart(i, canteen.name)}
                    onRemoveFromCart={removeFromCart}
                  />
                </View>
              ))}
            </View>
          )}
        </View>
      </ScrollView>

      {itemCount > 0 && (
        <View style={styles.stickyCartBar}>
          <View><Text style={styles.cartBarCount}>{itemCount} ITEMS</Text><Text style={styles.cartBarTotal}>₹{subtotal}</Text></View>
          <TouchableOpacity style={styles.cartBarButton} onPress={() => navigation.navigate('StudentRoot', { screen: 'Cart' })} activeOpacity={0.85}>
            <Text style={styles.cartBarButtonText}>VIEW CART</Text><ShoppingBag size={16} color="#FFFFFF" />
          </TouchableOpacity>
        </View>
      )}
    </SafeAreaView>
  );
};