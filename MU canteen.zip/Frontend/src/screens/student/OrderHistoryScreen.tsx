import React, { useState, useEffect } from 'react';
import { 
  View, 
  Text, 
  FlatList, 
  TouchableOpacity 
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { ArrowLeft, History } from 'lucide-react-native';
import { colors } from '../../config/theme';
import { OrderCardCompact } from '../../components/common/OrderCardCompact';
import { useAuth } from '../../context/AuthContext';
import { listenStudentOrders } from '../../services/firestoreService';
import { styles } from '../../styles/student/OrderHistoryStyles';
import type { Order } from '../../models/types';

interface OrderHistoryScreenProps {
  navigation: any;
}

export const OrderHistoryScreen: React.FC<OrderHistoryScreenProps> = ({ navigation }) => {
  const { user } = useAuth();
  const [orders, setOrders] = useState<Order[]>([]);

  useEffect(() => {
    if (!user) return;
    const unsub = listenStudentOrders(user.user_id, (data) => {
      setOrders(data);
    });
    return unsub;
  }, [user]);

  return (
    <SafeAreaView style={styles.safeArea}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backBtn}>
          <ArrowLeft size={26} color={colors.textPrimary} />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>My Order History</Text>
        <View style={{ width: 26 }} />
      </View>

      <View style={styles.container}>
        {orders.length === 0 ? (
          <View style={styles.emptyContainer}>
            <History size={64} color={colors.borderLight} />
            <Text style={styles.emptyTitle}>No past orders found</Text>
            <Text style={styles.emptySubtitle}>
              Your placed orders and daily pickup tokens will appear here.
            </Text>
          </View>
        ) : (
          <FlatList
            data={orders}
            keyExtractor={(item) => item.order_id}
            contentContainerStyle={styles.listContent}
            showsVerticalScrollIndicator={false}
            renderItem={({ item }) => (
              <OrderCardCompact
                order={item}
                isOperatorView={false}
                onPressTrack={(ord) => navigation.navigate('OrderTracking', { order: ord })}
              />
            )}
          />
        )}
      </View>
    </SafeAreaView>
  );
};