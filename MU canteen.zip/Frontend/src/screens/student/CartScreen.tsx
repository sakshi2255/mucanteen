import React, { useState } from 'react';
import { 
  View, 
  Text, 
  ScrollView, 
  TouchableOpacity, 
  ActivityIndicator, 
  Alert 
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { 
  ArrowLeft, 
  Trash2, 
  Plus, 
  Minus, 
  Clock, 
  Zap, 
  ShoppingBag, 
  Check,
  CreditCard,
  Banknote,
  Calendar
} from 'lucide-react-native';
import { colors, spacing } from '../../config/theme';
import { useAuth } from '../../context/AuthContext';
import { useCart } from '../../context/CartContext';
import { createOrderInFirestore } from '../../services/firestoreService';
import { getISTDateString } from '../../services/tokenService';
import { INITIAL_CANTEENS } from '../../services/seedData';
import { styles } from '../../styles/student/CartStyles';

interface CartScreenProps {
  navigation: any;
}

const PREORDER_SLOTS = [
  '10:30 AM (Morning Recess)',
  '12:45 PM (Lunch Break)',
  '02:15 PM (Afternoon Break)',
  '04:30 PM (Evening Tea)',
];

export const CartScreen: React.FC<CartScreenProps> = ({ navigation }) => {
  const { user } = useAuth();
  const { 
    items, 
    activeCanteenId, 
    activeCanteenName, 
    subtotal, 
    total, 
    orderType, 
    setOrderType,
    pickupTime, 
    setPickupTime,
    paymentMethod,
    setPaymentMethod,
    policyAccepted,
    addToCart, 
    removeFromCart, 
    clearCart 
  } = useCart();

  const [loading, setLoading] = useState(false);
  const todayIST = getISTDateString();

  const activeCanteen = INITIAL_CANTEENS.find(
    (c) => c.canteen_id === activeCanteenId
  ) || INITIAL_CANTEENS[0];

  const handleProceed = async () => {
    if (items.length === 0) return;
    if (!user) {
      Alert.alert('Authentication Required', 'Please sign in to place an order.');
      return;
    }
    if (orderType === 'preorder' && !policyAccepted) {
      navigation.navigate('PreorderPolicy');
      return;
    }

    setLoading(true);
    try {
      const orderItems = items.map((i) => ({
        menu_item_id: i.item.menu_item_id,
        item_name: i.item.item_name,
        price: i.item.price,
        quantity: i.quantity,
        subtotal: i.item.price * i.quantity,
        is_veg: i.item.is_veg,
        placeholder_key: i.item.placeholder_key,
      }));

      const created = await createOrderInFirestore({
        user,
        canteen: activeCanteen,
        items: orderItems,
        subtotal,
        total,
        order_type: orderType,
        pickup_time: orderType === 'preorder' ? pickupTime : 'Immediate',
        payment_method: paymentMethod,
        policy_version: '1.0.0',
        policy_accepted: orderType === 'preorder' ? true : false,
      });

      clearCart();
      navigation.navigate('OrderTracking', { order: created });
    } catch (e: any) {
      Alert.alert('Checkout Failed', e.message || 'Could not place order.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <SafeAreaView style={styles.safeArea}>
      <View style={styles.topHeader}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backButton}>
          <ArrowLeft size={26} color={colors.textPrimary} />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Cart Summary</Text>
        {items.length > 0 ? (
          <TouchableOpacity onPress={clearCart} style={styles.clearBtn}>
            <Text style={styles.clearBtnText}>CLEAR</Text>
          </TouchableOpacity>
        ) : <View style={{ width: 40 }}/>}
      </View>

      {items.length === 0 ? (
        <View style={styles.emptyContainer}>
          <ShoppingBag size={80} color={colors.borderLight} />
          <Text style={styles.emptyTitle}>Your cart is empty</Text>
          <Text style={styles.emptySubtitle}>Good food is always cooking! Go ahead and order some delicious items.</Text>
          <TouchableOpacity style={styles.browseButton} onPress={() => navigation.navigate('StudentHome')}>
            <Text style={styles.browseButtonText}>Browse Restaurants</Text>
          </TouchableOpacity>
        </View>
      ) : (
        <ScrollView style={styles.container} contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
          
          <View style={styles.canteenBanner}>
            <Text style={styles.canteenBannerTitle}>{activeCanteenName || activeCanteen.name}</Text>
            <Text style={styles.canteenBannerSubtitle}>
              Floor {activeCanteen.floor === 0 ? 'Ground' : activeCanteen.floor} • Token Prefix [{activeCanteen.token_prefix || 'A'}]
            </Text>
          </View>

          {/* Cart Items List */}
          <View style={styles.itemsCard}>
            {items.map(({ item, quantity }) => (
              <View key={item.menu_item_id} style={styles.cartItemRow}>
                <View style={styles.itemInfo}>
                  <View 
                    style={[
                      styles.vegIndicatorDot, 
                      { backgroundColor: item.is_veg ? colors.accentGreen : colors.accentRed }
                    ]} 
                  />
                  <View>
                    <Text style={styles.itemName}>{item.item_name}</Text>
                    <Text style={styles.itemPrice}>₹{item.price}</Text>
                  </View>
                </View>

                <View style={styles.stepperSubtotalGroup}>
                  <View style={styles.stepper}>
                    <TouchableOpacity onPress={() => removeFromCart(item)} style={styles.stepBtn}>
                      {quantity === 1 ? <Trash2 size={15} color={colors.accentRed} /> : <Minus size={15} color={colors.primaryDark} />}
                    </TouchableOpacity>
                    <Text style={styles.stepQty}>{quantity}</Text>
                    <TouchableOpacity onPress={() => addToCart(item)} style={styles.stepBtn}>
                      <Plus size={15} color={colors.primaryDark} />
                    </TouchableOpacity>
                  </View>
                  <Text style={styles.itemSubtotal}>₹{item.price * quantity}</Text>
                </View>
              </View>
            ))}
          </View>

          {/* Ordering Mode */}
          <View style={styles.sectionCard}>
            <Text style={styles.sectionHeading}>Ordering Mode</Text>
            <View style={styles.typeToggleRow}>
              <TouchableOpacity 
                style={[styles.typeButton, orderType === 'instant' && styles.activeTypeButton]}
                onPress={() => setOrderType('instant')}
                activeOpacity={0.9}
              >
                <Zap size={18} color={orderType === 'instant' ? '#FFFFFF' : colors.textSecondary} />
                <Text style={[styles.typeButtonText, orderType === 'instant' && styles.activeTypeButtonText]}>Instant</Text>
              </TouchableOpacity>
              <TouchableOpacity 
                style={[styles.typeButton, orderType === 'preorder' && styles.activeTypeButton]}
                onPress={() => setOrderType('preorder')}
                activeOpacity={0.9}
              >
                <Clock size={18} color={orderType === 'preorder' ? '#FFFFFF' : colors.textSecondary} />
                <Text style={[styles.typeButtonText, orderType === 'preorder' && styles.activeTypeButtonText]}>Preorder</Text>
              </TouchableOpacity>
            </View>

            {orderType === 'preorder' && (
              <View style={styles.slotsContainer}>
                <View style={styles.sameDayNotice}>
                  <Calendar size={14} color={colors.primaryDark} />
                  <Text style={styles.sameDayText}>Scheduling for Today ({todayIST})</Text>
                </View>
                <Text style={styles.slotHeading}>Select Break Slot:</Text>
                {PREORDER_SLOTS.map((slot) => {
                  const isSelected = pickupTime === slot;
                  return (
                    <TouchableOpacity
                      key={slot}
                      style={[styles.slotItem, isSelected && styles.activeSlotItem]}
                      onPress={() => setPickupTime(slot)}
                      activeOpacity={0.7}
                    >
                      <Text style={[styles.slotText, isSelected && styles.activeSlotText]}>{slot}</Text>
                      {isSelected && <Check size={18} color={colors.primary} />}
                    </TouchableOpacity>
                  );
                })}
              </View>
            )}
          </View>

          {/* Payment Method */}
          <View style={styles.sectionCard}>
            <Text style={styles.sectionHeading}>Payment Method</Text>
            <TouchableOpacity
              style={[styles.paymentCard, paymentMethod === 'online_demo' && styles.activePaymentCard]}
              onPress={() => setPaymentMethod('online_demo')}
            >
              <CreditCard size={22} color={paymentMethod === 'online_demo' ? colors.primary : colors.textSecondary} />
              <View style={{ flex: 1, marginLeft: spacing.md }}>
                <Text style={[styles.paymentTitle, paymentMethod === 'online_demo' && styles.activePaymentTitle]}>Online Payment</Text>
                <Text style={styles.paymentSub}>Campus UPI & card payment</Text>
              </View>
              {paymentMethod === 'online_demo' && <Check size={20} color={colors.primary} />}
            </TouchableOpacity>

            <TouchableOpacity
              style={[styles.paymentCard, paymentMethod === 'cash' && styles.activePaymentCard]}
              onPress={() => setPaymentMethod('cash')}
            >
              <Banknote size={22} color={paymentMethod === 'cash' ? '#D97706' : colors.textSecondary} />
              <View style={{ flex: 1, marginLeft: spacing.md }}>
                <Text style={[styles.paymentTitle, paymentMethod === 'cash' && styles.activePaymentTitle]}>Pay with Cash</Text>
                <Text style={styles.paymentSub}>Pay at the canteen counter</Text>
              </View>
              {paymentMethod === 'cash' && <Check size={20} color={colors.primary} />}
            </TouchableOpacity>
          </View>

          {/* Swiggy Style Bill Breakdown */}
          <View style={styles.billCard}>
            <Text style={styles.sectionHeading}>Bill Details</Text>
            <View style={styles.billRow}>
              <Text style={styles.billLabel}>Item Total</Text>
              <Text style={styles.billValue}>₹{subtotal}</Text>
            </View>
            <View style={styles.billRow}>
              <Text style={styles.billLabel}>Platform Fee</Text>
              <Text style={[styles.billValue, { color: colors.accentGreen }]}>FREE</Text>
            </View>
            
            <View style={styles.billDivider} />
            
            <View style={styles.totalRow}>
              <Text style={styles.totalLabel}>TO PAY</Text>
              <Text style={styles.totalValue}>₹{total}</Text>
            </View>
          </View>
        </ScrollView>
      )}

      {/* Edge-to-Edge Sticky Bottom Action */}
      {items.length > 0 && (
        <View style={styles.bottomCheckoutBar}>
          <TouchableOpacity
            style={[styles.checkoutBtn, loading && styles.disabledBtn]}
            onPress={handleProceed}
            disabled={loading}
            activeOpacity={0.9}
          >
            {loading ? (
              <ActivityIndicator color="#FFFFFF" size="small" />
            ) : (
              <>
                <View>
                  <Text style={styles.btnTotalLabel}>₹{total}</Text>
                  <Text style={styles.btnTotalSub}>TOTAL</Text>
                </View>
                <Text style={styles.checkoutBtnText}>
                  {orderType === 'preorder' && !policyAccepted 
                    ? 'REVIEW POLICY  >' 
                    : 'PLACE ORDER  >'}
                </Text>
              </>
            )}
          </TouchableOpacity>
        </View>
      )}
    </SafeAreaView>
  );
};