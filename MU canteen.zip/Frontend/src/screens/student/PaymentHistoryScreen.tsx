import React, { useEffect, useState } from 'react';
import { View, Text, FlatList, TouchableOpacity } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { ArrowLeft, Banknote, CreditCard } from 'lucide-react-native';
import { colors } from '../../config/theme';
import { useAuth } from '../../context/AuthContext';
import { listenPaymentHistory } from '../../services/firestoreService';
import { styles } from '../../styles/student/PaymentHistoryStyles';
import type { PaymentHistory } from '../../models/types';

export const PaymentHistoryScreen = ({ navigation }: any) => {
  const { user } = useAuth();
  const [payments, setPayments] = useState<PaymentHistory[]>([]);
  const [totalSpent, setTotalSpent] = useState(0);

  useEffect(() => {
    if (!user) return;
    const unsub = listenPaymentHistory(user.user_id, (data) => {
      setPayments(data);
      setTotalSpent(data.reduce((sum, item) => sum + item.price, 0));
    });
    return unsub;
  }, [user]);

  return (
    <SafeAreaView style={styles.safeArea}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backBtn}>
          <ArrowLeft size={22} color={colors.textPrimary} />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Payment History</Text>
        <View style={{ width: 22 }} />
      </View>

      <View style={styles.statsCard}>
        <Text style={styles.statsLabel}>Total Campus Spend</Text>
        <Text style={styles.statsValue}>₹{totalSpent}</Text>
      </View>

      <FlatList
        data={payments}
        keyExtractor={(item) => item.payment_id}
        contentContainerStyle={styles.listContent}
        renderItem={({ item }) => (
          <View style={styles.paymentCard}>
            <View style={styles.iconBox}>
              {item.payment_mode === 'cash' ? <Banknote size={20} color="#D97706" /> : <CreditCard size={20} color={colors.primary} />}
            </View>
            <View style={styles.detailsCol}>
              <Text style={styles.orderId}>Order #{item.order_id.slice(-6).toUpperCase()}</Text>
              <Text style={styles.dateText}>{new Date(item.timestamp).toLocaleString()}</Text>
            </View>
            <View style={styles.priceCol}>
              <Text style={styles.priceText}>₹{item.price}</Text>
              <View style={[styles.statusPill, { backgroundColor: item.payment_status === 'CASH_PENDING' ? '#FEF3C7' : '#ECFDF5' }]}>
                <Text style={[styles.statusText, { color: item.payment_status === 'CASH_PENDING' ? '#B45309' : colors.accentGreen }]}>
                  {item.payment_status === 'CASH_PENDING' ? 'PENDING' : 'PAID'}
                </Text>
              </View>
            </View>
          </View>
        )}
      />
    </SafeAreaView>
  );
};
