import React, { useCallback } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  FlatList,
  SafeAreaView,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { ArrowLeft, BellOff, Settings } from 'lucide-react-native';
import { useNotifications } from '../../context/NotificationContext';
import { colors } from '../../config/theme';
import { styles } from '../../styles/student/NotificationsStyles';
import type { AppNotification } from '../../models/types';

function formatRelativeTime(isoString: string): string {
  const date = new Date(isoString);
  const now = Date.now();
  const diffMs = now - date.getTime();
  const diffMins = Math.floor(diffMs / 60000);

  if (diffMins < 1) return 'Just now';
  if (diffMins < 60) return `${diffMins}m ago`;
  const diffHours = Math.floor(diffMins / 60);
  if (diffHours < 24) return `${diffHours}h ago`;
  const diffDays = Math.floor(diffHours / 24);
  if (diffDays === 1) return 'Yesterday';
  return `${diffDays}d ago`;
}

function NotificationItem({
  item,
  onPress,
}: {
  item: AppNotification;
  onPress: (id: string) => void;
}) {
  return (
    <TouchableOpacity
      style={[styles.notifCard, !item.is_read && styles.notifCardUnread]}
      onPress={() => onPress(item.notification_id)}
      activeOpacity={0.75}
    >
      <View style={styles.unreadDotWrapper}>
        <View style={item.is_read ? styles.readDot : styles.unreadDot} />
      </View>
      <View style={styles.notifBody}>
        <Text style={[styles.notifTitle, item.is_read && styles.notifTitleRead]}>
          {item.title}
        </Text>
        <Text style={styles.notifMessage}>{item.body}</Text>
        <Text style={styles.notifTime}>{formatRelativeTime(item.created_at)}</Text>
      </View>
    </TouchableOpacity>
  );
}

export function NotificationsScreen() {
  const navigation = useNavigation<any>();
  const { notifications, unreadCount, markAsRead, markAllRead } = useNotifications();

  const handlePress = useCallback(
    (id: string) => {
      markAsRead(id);
    },
    [markAsRead]
  );

  const renderItem = useCallback(
    ({ item }: { item: AppNotification }) => (
      <NotificationItem item={item} onPress={handlePress} />
    ),
    [handlePress]
  );

  const keyExtractor = (item: AppNotification) => item.notification_id;

  return (
    <SafeAreaView style={styles.safeArea}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity style={styles.backBtn} onPress={() => navigation.goBack()}>
          <ArrowLeft size={22} color={colors.textPrimary} />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>
          Notifications{unreadCount > 0 ? ` (${unreadCount})` : ''}
        </Text>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 10 }}>
          {unreadCount > 0 && (
            <TouchableOpacity style={styles.markAllBtn} onPress={markAllRead}>
              <Text style={styles.markAllText}>Mark all read</Text>
            </TouchableOpacity>
          )}
          <TouchableOpacity
            style={styles.backBtn}
            onPress={() => navigation.navigate('NotificationSettings')}
            accessibilityLabel="Notification Settings"
          >
            <Settings size={20} color={colors.primary} />
          </TouchableOpacity>
        </View>
      </View>

      <FlatList
        style={styles.container}
        contentContainerStyle={
          notifications.length === 0
            ? { flex: 1 }
            : styles.listContent
        }
        data={notifications}
        keyExtractor={keyExtractor}
        renderItem={renderItem}
        ListEmptyComponent={
          <View style={styles.emptyContainer}>
            <BellOff size={56} color={colors.textMuted} />
            <Text style={styles.emptyTitle}>No Notifications</Text>
            <Text style={styles.emptySubtitle}>
              You'll see order updates and alerts here when they arrive.
            </Text>
          </View>
        }
      />
    </SafeAreaView>
  );
}

export default NotificationsScreen;
