import { createNotificationForUser } from './firestoreService';
import type { AppNotification, NotificationSettings } from '../models/types';

type NotificationType = AppNotification['type'];

interface NotificationPayload {
  title: string;
  body: string;
  type: NotificationType;
}

function buildPayload(
  status: NotificationType,
  canteenName: string,
  tokenDisplay: string
): NotificationPayload {
  switch (status) {
    case 'order_placed':
      return {
        title: '🛍️ Order Placed',
        body: `Your order ${tokenDisplay} has been placed at ${canteenName}. Waiting for confirmation.`,
        type: 'order_placed',
      };
    case 'order_accepted':
      return {
        title: '✅ Order Accepted',
        body: `Your order ${tokenDisplay} at ${canteenName} has been accepted and will be prepared shortly.`,
        type: 'order_accepted',
      };
    case 'order_preparing':
      return {
        title: '👨‍🍳 Preparing Your Order',
        body: `Your order ${tokenDisplay} at ${canteenName} is now being prepared.`,
        type: 'order_preparing',
      };
    case 'order_ready':
      return {
        title: '🔔 Ready for Pickup!',
        body: `Your order ${tokenDisplay} at ${canteenName} is ready. Please collect within 12 minutes.`,
        type: 'order_ready',
      };
    case 'order_declined':
      return {
        title: '❌ Order Declined',
        body: `Your order ${tokenDisplay} at ${canteenName} was declined by the canteen.`,
        type: 'order_declined',
      };
    case 'order_cancelled':
      return {
        title: 'Order Cancelled',
        body: `Your order ${tokenDisplay} has been cancelled.`,
        type: 'order_cancelled',
      };
    case 'pickup_warning':
      return {
        title: '⏰ Pickup Deadline Soon!',
        body: `You have 2 minutes left to collect order ${tokenDisplay} from ${canteenName}.`,
        type: 'pickup_warning',
      };
    case 'pickup_failed':
      return {
        title: '⚠️ Order Not Collected',
        body: `Your order ${tokenDisplay} from ${canteenName} was not collected in time and has been marked as expired.`,
        type: 'pickup_failed',
      };
    default:
      return {
        title: 'Order Update',
        body: `Your order ${tokenDisplay} status has been updated.`,
        type: status,
      };
  }
}

export async function scheduleOrderStatusNotification(
  userId: string,
  orderId: string,
  status: NotificationType,
  canteenName: string,
  tokenDisplay: string,
  settings?: NotificationSettings
): Promise<void> {
  // Check if user has this notification type enabled (defaults to true if settings not loaded)
  if (settings) {
    const settingKey = status as keyof NotificationSettings;
    if (settingKey in settings && settings[settingKey] === false) {
      return;
    }
  }

  const payload = buildPayload(status, canteenName, tokenDisplay);

  await createNotificationForUser(userId, {
    order_id: orderId,
    title: payload.title,
    body: payload.body,
    type: payload.type,
  });
}

export async function schedule2MinWarningNotification(
  userId: string,
  orderId: string,
  canteenName: string,
  tokenDisplay: string
): Promise<void> {
  await createNotificationForUser(userId, {
    order_id: orderId,
    title: '⏰ Pickup Deadline Soon!',
    body: `You have 2 minutes left to collect order ${tokenDisplay} from ${canteenName}.`,
    type: 'pickup_warning',
  });
}

export async function schedulePickupFailedNotification(
  userId: string,
  orderId: string,
  canteenName: string,
  tokenDisplay: string
): Promise<void> {
  await createNotificationForUser(userId, {
    order_id: orderId,
    title: '⚠️ Order Not Collected',
    body: `Your order ${tokenDisplay} from ${canteenName} was not collected in time.`,
    type: 'pickup_failed',
  });
}

export async function requestPermissions(): Promise<boolean> {
  if (typeof window !== 'undefined' && 'Notification' in window) {
    try {
      const res = await Notification.requestPermission();
      return res === 'granted';
    } catch {
      return false;
    }
  }
  return true;
}

// Cancellation is a no-op for Firestore-based in-app notifications
export async function cancelNotificationsForOrder(_orderId: string): Promise<void> {
  // No scheduled native notifications to cancel in this in-app approach
}
