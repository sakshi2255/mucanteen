import { 
  collection, doc, getDoc, getDocs, setDoc, updateDoc, deleteDoc,
  onSnapshot, query, where, orderBy, runTransaction, limit, Unsubscribe 
} from 'firebase/firestore';
import { auth, db } from '../config/firebaseConfig';
import { getISTDateString, calculateNextTokenWithPrefix, type OrderCounter } from './tokenService';
import { INITIAL_CANTEENS, INITIAL_CATEGORIES, INITIAL_MENU_ITEMS, INITIAL_PROMOTIONS } from './seedData';
import type { 
  Canteen, MenuCategory, MenuItem, Order, OrderStatus, 
  PaymentMethod, PaymentStatus, Promotion, UserProfile, 
  AuditLog, PaymentHistory, Revenue 
} from '../models/types';

let localOrders: Order[] = [];
let localCanteens: Canteen[] = [...INITIAL_CANTEENS];
let localMenuItems: MenuItem[] = [...INITIAL_MENU_ITEMS];
let localPromotions: Promotion[] = [...INITIAL_PROMOTIONS];
let localCategories: MenuCategory[] = [...INITIAL_CATEGORIES];
let localPaymentHistory: PaymentHistory[] = [];
let localRevenue: Revenue[] = [];
let localNotifications: import('../models/types').AppNotification[] = [];

export async function initializeFirestoreIfNeeded(): Promise<void> {
  try {
    const canteensSnap = await getDocs(collection(db, 'canteens'));
    if (canteensSnap.empty) {
      for (const canteen of INITIAL_CANTEENS) {
        await setDoc(doc(db, 'canteens', canteen.canteen_id), canteen);
      }
    }
    const categoriesSnap = await getDocs(collection(db, 'menuCategories'));
    if (categoriesSnap.empty) {
      for (const cat of INITIAL_CATEGORIES) {
        await setDoc(doc(db, 'menuCategories', cat.menu_category_id), cat);
      }
    }
    const itemsSnap = await getDocs(collection(db, 'menuItems'));
    if (itemsSnap.empty) {
      for (const item of INITIAL_MENU_ITEMS) {
        await setDoc(doc(db, 'menuItems', item.menu_item_id), item);
      }
    }
    const promoSnap = await getDocs(collection(db, 'promotions'));
    if (promoSnap.empty) {
      for (const promo of INITIAL_PROMOTIONS) {
        await setDoc(doc(db, 'promotions', promo.promotion_id), promo);
      }
    }

    // Seed payments_history and payment_history if empty
    try {
      const paymentsSnap = await getDocs(collection(db, 'payments_history'));
      if (paymentsSnap.empty) {
        const samplePayments: PaymentHistory[] = [
          {
            id: 'pay_init_1',
            payment_id: 'pay_init_1',
            order_id: 'ord_init_1',
            user_id: 'usr_student_1',
            canteen_id: 'canteen_main_1',
            payment_mode: 'online_demo',
            price: 70,
            payment_status: 'PAID_ONLINE_DEMO',
            timestamp: new Date().toISOString(),
          },
          {
            id: 'pay_init_2',
            payment_id: 'pay_init_2',
            order_id: 'ord_init_2',
            user_id: 'usr_student_2',
            canteen_id: 'canteen_main_2',
            payment_mode: 'cash',
            price: 110,
            payment_status: 'CASH_RECEIVED',
            timestamp: new Date().toISOString(),
          }
        ];
        for (const payment of samplePayments) {
          await setDoc(doc(db, 'payments_history', payment.payment_id), payment);
          await setDoc(doc(db, 'payment_history', payment.payment_id), payment);
          localPaymentHistory.push(payment);
        }
      }
    } catch (payError) {
      console.warn('Payments history seeding notice:', payError);
    }

    // Seed Revenue (and revenue) if empty
    try {
      const revenueSnap = await getDocs(collection(db, 'Revenue'));
      if (revenueSnap.empty) {
        const todayStr = getISTDateString();
        const ordersSnap = await getDocs(
          query(collection(db, 'orders'), where('order_status', '==', 'picked_up'))
        );
        const revenueMap: Record<string, { total_revenue: number; total_orders: number; canteen_id: string; date: string }> = {};

        // Base revenue entry for each canteen today
        for (const canteen of INITIAL_CANTEENS) {
          const key = `rev_${canteen.canteen_id}_${todayStr}`;
          revenueMap[key] = { total_revenue: 0, total_orders: 0, canteen_id: canteen.canteen_id, date: todayStr };
        }

        if (!ordersSnap.empty) {
          ordersSnap.docs.forEach((d) => {
            const o = d.data() as Order;
            const key = `rev_${o.canteen_id}_${o.token_date}`;
            if (!revenueMap[key]) {
              revenueMap[key] = { total_revenue: 0, total_orders: 0, canteen_id: o.canteen_id, date: o.token_date };
            }
            revenueMap[key].total_revenue += o.total;
            revenueMap[key].total_orders += 1;
          });
        }

        const updatedAt = new Date().toISOString();
        for (const [revenueId, rev] of Object.entries(revenueMap)) {
          const revDoc = {
            id: revenueId,
            revenue_id: revenueId,
            canteen_id: rev.canteen_id,
            date: rev.date,
            total_orders: rev.total_orders,
            total_revenue: rev.total_revenue,
            updated_at: updatedAt,
          };
          await setDoc(doc(db, 'Revenue', revenueId), revDoc);
          await setDoc(doc(db, 'revenue', revenueId), revDoc);
          localRevenue.push(revDoc);
        }
      }
    } catch (revError) {
      console.warn('Revenue seeding notice:', revError);
    }
  } catch (error) {
    console.warn('Firestore initialization notice (operating with memory store if offline):', error);
  }
}

export function listenCanteens(callback: (canteens: Canteen[]) => void): Unsubscribe {
  try {
    const q = query(collection(db, 'canteens'), where('is_active', '==', true));
    return onSnapshot(q, (snapshot) => {
      if (!snapshot.empty) {
        const canteens = snapshot.docs.map((d) => d.data() as Canteen);
        localCanteens = canteens;
        callback(canteens);
      } else {
        callback(localCanteens);
      }
    }, (error) => {
      console.warn('Canteens listener fallback:', error.message);
      callback(localCanteens);
    });
  } catch (err) {
    callback(localCanteens);
    return () => {};
  }
}

export function listenPromotions(callback: (promotions: Promotion[]) => void): Unsubscribe {
  try {
    const q = query(collection(db, 'promotions'), where('is_active', '==', true));
    return onSnapshot(q, (snapshot) => {
      if (!snapshot.empty) {
        const promos = snapshot.docs.map((d) => d.data() as Promotion);
        localPromotions = promos;
        callback(promos);
      } else {
        callback(localPromotions);
      }
    }, (error) => {
      console.warn('Promotions listener fallback:', error.message);
      callback(localPromotions);
    });
  } catch (err) {
    callback(localPromotions);
    return () => {};
  }
}

export function listenCategories(callback: (categories: MenuCategory[]) => void): Unsubscribe {
  try {
    const q = query(collection(db, 'menuCategories'), where('is_active', '==', true));
    return onSnapshot(q, (snapshot) => {
      if (!snapshot.empty) {
        const cats = snapshot.docs.map((d) => d.data() as MenuCategory);
        localCategories = cats;
        callback(cats);
      } else {
        callback(localCategories);
      }
    }, (error) => {
      console.warn('Categories listener fallback:', error.message);
      callback(localCategories);
    });
  } catch (err) {
    callback(localCategories);
    return () => {};
  }
}

export function listenMenuItems(canteenId: string | null, callback: (items: MenuItem[]) => void): Unsubscribe {
  try {
    const coll = collection(db, 'menuItems');
    const q = canteenId 
      ? query(coll, where('canteen_id', '==', canteenId), where('is_active', '==', true))
      : query(coll, where('is_active', '==', true));
    return onSnapshot(q, (snapshot) => {
      if (!snapshot.empty) {
        const items = snapshot.docs.map((d) => d.data() as MenuItem);
        callback(items);
      } else {
        const filtered = canteenId ? localMenuItems.filter((i) => i.canteen_id === canteenId && i.is_active) : localMenuItems.filter(i => i.is_active);
        callback(filtered);
      }
    }, (error) => {
      console.warn('Menu items listener fallback:', error.message);
      const filtered = canteenId ? localMenuItems.filter((i) => i.canteen_id === canteenId && i.is_active) : localMenuItems.filter(i => i.is_active);
      callback(filtered);
    });
  } catch (err) {
    callback(canteenId ? localMenuItems.filter((i) => i.canteen_id === canteenId && i.is_active) : localMenuItems.filter(i => i.is_active));
    return () => {};
  }
}

export function listenOperatorOrders(canteenId: string, callback: (orders: Order[]) => void): Unsubscribe {
  try {
    const q = query(collection(db, 'orders'), where('canteen_id', '==', canteenId), orderBy('created_at', 'desc'));
    return onSnapshot(q, (snapshot) => {
      const orders = snapshot.docs.map((d) => d.data() as Order);
      for (const order of orders) {
        const idx = localOrders.findIndex((o) => o.order_id === order.order_id);
        if (idx >= 0) localOrders[idx] = order;
        else localOrders.push(order);
      }
      callback(orders);
    }, (error) => {
      console.warn('Operator orders listener fallback:', error.message);
      const filtered = localOrders.filter((o) => o.canteen_id === canteenId).sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
      callback(filtered);
    });
  } catch (err) {
    const filtered = localOrders.filter((o) => o.canteen_id === canteenId).sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
    callback(filtered);
    return () => {};
  }
}

export function listenStudentOrders(userId: string, callback: (orders: Order[]) => void): Unsubscribe {
  try {
    const q = query(collection(db, 'orders'), where('user_id', '==', userId), orderBy('created_at', 'desc'));
    return onSnapshot(q, (snapshot) => {
      const orders = snapshot.docs.map((d) => d.data() as Order);
      callback(orders);
    }, (error) => {
      console.warn('Student orders listener fallback:', error.message);
      const filtered = localOrders.filter((o) => o.user_id === userId).sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
      callback(filtered);
    });
  } catch (err) {
    const filtered = localOrders.filter((o) => o.user_id === userId).sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime());
    callback(filtered);
    return () => {};
  }
}

export function listenAllOrders(callback: (orders: Order[]) => void): Unsubscribe {
  try {
    const q = query(collection(db, 'orders'), orderBy('created_at', 'desc'), limit(100));
    return onSnapshot(q, (snapshot) => {
      const orders = snapshot.docs.map((d) => d.data() as Order);
      callback(orders);
    }, (error) => {
      console.warn('Admin orders listener fallback:', error.message);
      callback([...localOrders].sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime()));
    });
  } catch (err) {
    callback([...localOrders].sort((a, b) => new Date(b.created_at).getTime() - new Date(a.created_at).getTime()));
    return () => {};
  }
}

export async function recordPaymentHistory(payment: Omit<PaymentHistory, 'payment_id'>): Promise<void> {
  const paymentId = `pay_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
  const fullPayment: PaymentHistory = {
    ...payment,
    id: paymentId,
    payment_id: paymentId,
  };
  try {
    await setDoc(doc(db, 'payments_history', paymentId), fullPayment);
    await setDoc(doc(db, 'payment_history', paymentId), fullPayment);
  } catch (e) {
    console.warn('Payment logging fallback:', e);
  }
  localPaymentHistory.push(fullPayment);
}

export async function updateDailyRevenue(canteenId: string, amount: number, date: string = getISTDateString()): Promise<void> {
  const revenueId = `rev_${canteenId}_${date}`;
  try {
    const ref = doc(db, 'Revenue', revenueId);
    const snap = await getDoc(ref);
    if (snap.exists()) {
      const data = snap.data() as Revenue;
      const updatedData = {
        total_orders: (data.total_orders || 0) + 1,
        total_revenue: (data.total_revenue || 0) + amount,
        updated_at: new Date().toISOString()
      };
      await updateDoc(ref, updatedData);
      try {
        await updateDoc(doc(db, 'revenue', revenueId), updatedData);
      } catch {}
    } else {
      const revDoc = {
        id: revenueId,
        revenue_id: revenueId,
        canteen_id: canteenId,
        date,
        total_orders: 1,
        total_revenue: amount,
        updated_at: new Date().toISOString()
      };
      await setDoc(ref, revDoc);
      try {
        await setDoc(doc(db, 'revenue', revenueId), revDoc);
      } catch {}
    }
  } catch (e) {
    console.warn('Revenue update fallback:', e);
  }
}

export async function createOrderInFirestore(orderInput: {
  user: UserProfile;
  canteen: Canteen;
  items: Order['items_snapshot'];
  subtotal: number;
  total: number;
  order_type: 'instant' | 'preorder';
  pickup_time: string;
  payment_method: PaymentMethod;
  policy_version: string;
  policy_accepted: boolean;
}): Promise<Order> {
  const targetDateIST = getISTDateString();
  const canteenId = orderInput.canteen.canteen_id;
  const tokenPrefix = (orderInput.canteen.token_prefix || 'A').toUpperCase();
  const orderDocRef = doc(collection(db, 'orders'));
  const orderId = orderDocRef.id;
  const nowIso = new Date().toISOString();
  const effectiveUserId = auth.currentUser?.uid || orderInput.user.user_id;

  const paymentStatus: PaymentStatus = orderInput.payment_method === 'online_demo' ? 'PAID_ONLINE_DEMO' : 'CASH_PENDING';

  let allocatedToken = 1;
  let tokenDisplay = `${tokenPrefix}1`;

  try {
    await runTransaction(db, async (transaction) => {
      const counterRef = doc(db, 'orderCounters', canteenId);
      const counterSnap = await transaction.get(counterRef);
      const currentCounter = counterSnap.exists() ? (counterSnap.data() as OrderCounter) : null;

      const calc = calculateNextTokenWithPrefix(currentCounter, targetDateIST, canteenId, tokenPrefix);
      allocatedToken = calc.allocatedToken;
      tokenDisplay = calc.tokenDisplay;
      transaction.set(counterRef, calc.newCounter);

      const initialStatus: OrderStatus = orderInput.canteen.acceptance_mode === 'automatic' ? 'preparing' : 'awaiting_acceptance';

      const newOrder: Order = {
        order_id: orderId,
        token_display: tokenDisplay,
        daily_token_number: allocatedToken,
        token_prefix: tokenPrefix,
        token_date: targetDateIST,
        canteen_id: canteenId,
        canteen_name_snapshot: orderInput.canteen.name,
        user_id: effectiveUserId,
        user_name_snapshot: orderInput.user.name,
        user_role_snapshot: orderInput.user.role_id,
        order_type: orderInput.order_type,
        items_snapshot: orderInput.items,
        subtotal: orderInput.subtotal,
        total: orderInput.total,
        payment_method: orderInput.payment_method,
        payment_status: paymentStatus,
        order_status: initialStatus,
        pickup_time: orderInput.pickup_time,
        pickup_date: targetDateIST,
        policy_version: orderInput.policy_version,
        policy_accepted_at: orderInput.policy_accepted ? nowIso : null,
        ready_at: null,
        collection_deadline: null,
        collected_time: null,
        collected_status: 'pending',
        cash_received_at: null,
        created_at: nowIso,
        updated_at: nowIso,
        idempotency_key: `idemp_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      };

      transaction.set(orderDocRef, newOrder);
    });
  } catch (error) {
    console.warn('Transaction fallback to local state:', error);
    const todayOrders = localOrders.filter((o) => o.canteen_id === canteenId && o.token_date === targetDateIST);
    allocatedToken = todayOrders.length + 1;
    tokenDisplay = `${tokenPrefix}${allocatedToken}`;

    const fallbackOrder: Order = {
      order_id: orderId, token_display: tokenDisplay, daily_token_number: allocatedToken, token_prefix: tokenPrefix, token_date: targetDateIST,
      canteen_id: canteenId, canteen_name_snapshot: orderInput.canteen.name, user_id: effectiveUserId, user_name_snapshot: orderInput.user.name, user_role_snapshot: orderInput.user.role_id,
      order_type: orderInput.order_type, items_snapshot: orderInput.items, subtotal: orderInput.subtotal, total: orderInput.total, payment_method: orderInput.payment_method, payment_status: paymentStatus,
      order_status: orderInput.canteen.acceptance_mode === 'automatic' ? 'preparing' : 'awaiting_acceptance', pickup_time: orderInput.pickup_time, pickup_date: targetDateIST,
      policy_version: orderInput.policy_version, policy_accepted_at: orderInput.policy_accepted ? nowIso : null, ready_at: null, collection_deadline: null, collected_time: null, collected_status: 'pending', cash_received_at: null,
      created_at: nowIso, updated_at: nowIso, idempotency_key: `idemp_${Date.now()}`
    };
    localOrders.unshift(fallbackOrder);
  }

  let createdOrder: Order | undefined;
  try {
    const createdSnap = await getDoc(orderDocRef);
    if(createdSnap.exists()) createdOrder = createdSnap.data() as Order;
  } catch {
    createdOrder = localOrders.find(o => o.order_id === orderId);
  }
  if (!createdOrder) throw new Error("Order creation failed.");

  await recordPaymentHistory({
    order_id: orderId,
    user_id: effectiveUserId,
    canteen_id: canteenId,
    payment_mode: orderInput.payment_method,
    price: orderInput.total,
    payment_status: paymentStatus,
    timestamp: nowIso
  });

  if (paymentStatus === 'PAID_ONLINE_DEMO') {
    await updateDailyRevenue(canteenId, orderInput.total, targetDateIST);
  }

  // System Notification for student/faculty
  await createNotificationForUser(effectiveUserId, {
    order_id: orderId,
    title: '🛍️ Order Placed',
    body: `Your order #${createdOrder.token_display} has been placed at ${orderInput.canteen.name}. Waiting for confirmation.`,
    type: 'order_placed',
  });

  // Notification for canteen operators
  try {
    const operatorsSnap = await getDocs(
      query(collection(db, 'users'), where('role_id', '==', 'operator'))
    );
    operatorsSnap.forEach((opDoc) => {
      const op = opDoc.data() as UserProfile;
      if (!op.assigned_canteen_ids || op.assigned_canteen_ids.length === 0 || op.assigned_canteen_ids.includes(canteenId)) {
        createNotificationForUser(op.user_id, {
          order_id: orderId,
          title: `🔔 New Order: Token #${createdOrder!.token_display}`,
          body: `New ${orderInput.order_type} order with ${orderInput.items.length} item(s) at ${orderInput.canteen.name}.`,
          type: 'order_placed',
        });
      }
    });
  } catch (opErr) {
    console.warn('Operator notification notice:', opErr);
  }

  await recordAuditLog({
    actor_id: effectiveUserId, actor_name_snapshot: orderInput.user.name, actor_role: orderInput.user.role_id,
    action: 'ORDER_CREATED', entity_type: 'order', entity_id: orderId, canteen_id: canteenId,
    description: `Order ${createdOrder.token_display} placed at ${orderInput.canteen.name} (${orderInput.order_type}, ${paymentStatus})`,
    before_data: null, after_data: createdOrder as unknown as Record<string, unknown>,
  });

  return createdOrder;
}

export async function updateOrderStatusInFirestore(orderId: string, newStatus: OrderStatus, actor: { id: string; name: string; role: string }): Promise<void> {
  const nowIso = new Date().toISOString();
  const existingOrder = localOrders.find((o) => o.order_id === orderId);

  if (existingOrder) {
    if (newStatus === 'cancelled' && existingOrder.order_status !== 'awaiting_acceptance') throw new Error('Order cannot be cancelled at this stage.');
    if (newStatus === 'ready_for_pickup' && existingOrder.payment_status === 'CASH_PENDING') throw new Error('Cannot mark order ready: Cash pending.');
  }

  const updates: Partial<Order> = { order_status: newStatus, updated_at: nowIso };

  if (newStatus === 'ready_for_pickup') {
    updates.ready_at = nowIso;
    updates.collection_deadline = new Date(Date.now() + 12 * 60 * 1000).toISOString();
  }
  if (newStatus === 'picked_up') {
    if (existingOrder?.collection_deadline && Date.now() > new Date(existingOrder.collection_deadline).getTime()) {
      updates.order_status = 'not_collected';
      updates.collected_status = 'expired';
    } else {
      updates.collected_time = nowIso;
      updates.collected_status = 'verified';
    }
  }

  try {
    await updateDoc(doc(db, 'orders', orderId), updates);
  } catch (error) {
    console.warn('Update order doc notice:', error);
  }

  const idx = localOrders.findIndex((o) => o.order_id === orderId);
  if (idx >= 0) localOrders[idx] = { ...localOrders[idx], ...updates };

  const currentOrder = existingOrder || localOrders.find((o) => o.order_id === orderId);

  // Trigger real-time notifications for status transitions
  if (currentOrder) {
    const cName = currentOrder.canteen_name_snapshot;
    const tDisp = currentOrder.token_display;
    const uId = currentOrder.user_id;

    if (newStatus === 'preparing') {
      await createNotificationForUser(uId, {
        order_id: orderId,
        title: '👨‍🍳 Preparing Your Order',
        body: `Your order #${tDisp} at ${cName} is now being prepared.`,
        type: 'order_preparing',
      });
    } else if (newStatus === 'ready_for_pickup') {
      await createNotificationForUser(uId, {
        order_id: orderId,
        title: '🔔 Ready for Pickup!',
        body: `Your order #${tDisp} at ${cName} is ready! Please collect within 12 minutes.`,
        type: 'order_ready',
      });
    } else if (newStatus === 'picked_up') {
      await createNotificationForUser(uId, {
        order_id: orderId,
        title: '🎉 Order Collected',
        body: `Your order #${tDisp} from ${cName} was successfully collected. Enjoy!`,
        type: 'order_ready',
      });
      // Ensure daily revenue is updated for picked up orders
      await updateDailyRevenue(currentOrder.canteen_id, currentOrder.total, currentOrder.token_date);
    } else if (newStatus === 'declined') {
      await createNotificationForUser(uId, {
        order_id: orderId,
        title: '❌ Order Declined',
        body: `Your order #${tDisp} was declined by ${cName}.`,
        type: 'order_declined',
      });
    } else if (newStatus === 'cancelled') {
      await createNotificationForUser(uId, {
        order_id: orderId,
        title: 'Order Cancelled',
        body: `Your order #${tDisp} has been cancelled.`,
        type: 'order_cancelled',
      });
    } else if (newStatus === 'not_collected') {
      await createNotificationForUser(uId, {
        order_id: orderId,
        title: '⚠️ Order Not Collected',
        body: `Your order #${tDisp} from ${cName} was not collected in time and has expired.`,
        type: 'pickup_failed',
      });
    }
  }

  await recordAuditLog({
    actor_id: actor.id, actor_name_snapshot: actor.name, actor_role: actor.role,
    action: `ORDER_STATUS_${newStatus.toUpperCase()}`, entity_type: 'order', entity_id: orderId, canteen_id: existingOrder?.canteen_id || null,
    description: `Order status updated to ${newStatus}`, before_data: existingOrder ? { status: existingOrder.order_status } : null, after_data: updates as unknown as Record<string, unknown>,
  });
}

export async function markCashReceivedInFirestore(orderId: string, actor: { id: string; name: string; role: string }): Promise<void> {
  const nowIso = new Date().toISOString();
  const existingOrder = localOrders.find((o) => o.order_id === orderId);
  const updates: Partial<Order> = { payment_status: 'CASH_RECEIVED', cash_received_at: nowIso, updated_at: nowIso };

  try {
    await updateDoc(doc(db, 'orders', orderId), updates);
  } catch (error) {
    console.warn('Mark cash received notice:', error);
  }

  const idx = localOrders.findIndex((o) => o.order_id === orderId);
  if (idx >= 0) localOrders[idx] = { ...localOrders[idx], ...updates };

  if (existingOrder) {
    await recordPaymentHistory({
      order_id: orderId, user_id: existingOrder.user_id, canteen_id: existingOrder.canteen_id,
      payment_mode: 'cash', price: existingOrder.total, payment_status: 'CASH_RECEIVED', timestamp: nowIso
    });
    await updateDailyRevenue(existingOrder.canteen_id, existingOrder.total, existingOrder.token_date);
  }

  await recordAuditLog({
    actor_id: actor.id, actor_name_snapshot: actor.name, actor_role: actor.role,
    action: 'PAYMENT_CASH_RECEIVED', entity_type: 'order', entity_id: orderId, canteen_id: existingOrder?.canteen_id || null,
    description: `Cash received for order ${orderId}`, before_data: { payment_status: 'CASH_PENDING' }, after_data: { payment_status: 'CASH_RECEIVED' },
  });
}

export async function checkAndExpireOrders(canteenId?: string): Promise<number> {
  const now = Date.now();
  let expiredCount = 0;
  const ordersToCheck = localOrders.filter(
    (o) =>
      o.order_status === 'ready_for_pickup' &&
      (!canteenId || o.canteen_id === canteenId) &&
      o.collection_deadline
  );

  for (const order of ordersToCheck) {
    const deadlineMs = new Date(order.collection_deadline!).getTime();
    const diffMs = deadlineMs - now;

    // 2-Minute pickup reminder notification
    if (diffMs > 0 && diffMs <= 2 * 60 * 1000) {
      const alreadyWarned = localNotifications.some(
        (n) => n.order_id === order.order_id && n.type === 'pickup_warning'
      );
      if (!alreadyWarned) {
        await createNotificationForUser(order.user_id, {
          order_id: order.order_id,
          title: '⏰ Pickup Deadline Soon!',
          body: `You have 2 minutes left to collect order #${order.token_display} from ${order.canteen_name_snapshot}.`,
          type: 'pickup_warning',
        });
      }
    }

    // Expiration check
    if (diffMs <= 0) {
      await updateOrderStatusInFirestore(order.order_id, 'not_collected', {
        id: 'system',
        name: 'Automated Timer System',
        role: 'system',
      });
      expiredCount++;
    }
  }
  return expiredCount;
}

export async function toggleFavouriteCanteen(userId: string, canteenId: string): Promise<string[]> {
  try {
    const userRef = doc(db, 'users', userId);
    const snap = await getDoc(userRef);
    let favs: string[] = snap.exists() ? ((snap.data() as UserProfile).favourite_canteen_ids || []) : [];
    const idx = favs.indexOf(canteenId);
    if (idx >= 0) favs.splice(idx, 1);
    else favs.push(canteenId);
    await updateDoc(userRef, { favourite_canteen_ids: favs, updated_at: new Date().toISOString() });
    return favs;
  } catch (e) {
    return [];
  }
}

export async function toggleMenuItemAvailability(itemId: string, isAvailable: boolean, actor: { id: string; name: string; role: string }): Promise<void> {
  try { await updateDoc(doc(db, 'menuItems', itemId), { is_available: isAvailable, updated_at: new Date().toISOString() }); } catch (e) {}
  const idx = localMenuItems.findIndex((i) => i.menu_item_id === itemId);
  if (idx >= 0) localMenuItems[idx].is_available = isAvailable;
  await recordAuditLog({ actor_id: actor.id, actor_name_snapshot: actor.name, actor_role: actor.role, action: isAvailable ? 'MENU_ITEM_AVAILABLE' : 'MENU_ITEM_SOLDOUT', entity_type: 'menuItem', entity_id: itemId, canteen_id: localMenuItems[idx]?.canteen_id || null, description: `Menu item marked as ${isAvailable ? 'AVAILABLE' : 'SOLD OUT'}`, before_data: null, after_data: { is_available: isAvailable } });
}

export async function addMenuItemFirestore(item: MenuItem, actor: { id: string; name: string; role: string }): Promise<MenuItem> {
  try { await setDoc(doc(db, 'menuItems', item.menu_item_id), item); } catch (e) {}
  localMenuItems.push(item);
  await recordAuditLog({ actor_id: actor.id, actor_name_snapshot: actor.name, actor_role: actor.role, action: 'MENU_ITEM_CREATED', entity_type: 'menuItem', entity_id: item.menu_item_id, canteen_id: item.canteen_id, description: `Added menu item ${item.item_name}`, before_data: null, after_data: item as unknown as Record<string, unknown> });
  return item;
}

export async function editMenuItemFirestore(itemId: string, updates: Partial<MenuItem>, actor: { id: string; name: string; role: string }): Promise<void> {
  const fullUpdates = { ...updates, updated_at: new Date().toISOString() };
  try { await updateDoc(doc(db, 'menuItems', itemId), fullUpdates); } catch (e) {}
  const idx = localMenuItems.findIndex((i) => i.menu_item_id === itemId);
  if (idx >= 0) localMenuItems[idx] = { ...localMenuItems[idx], ...fullUpdates };
  await recordAuditLog({ actor_id: actor.id, actor_name_snapshot: actor.name, actor_role: actor.role, action: 'MENU_ITEM_UPDATED', entity_type: 'menuItem', entity_id: itemId, canteen_id: localMenuItems[idx]?.canteen_id || null, description: `Updated menu item`, before_data: null, after_data: fullUpdates });
}

export async function deleteMenuItemFirestore(itemId: string, actor: { id: string; name: string; role: string }): Promise<void> {
  try { await updateDoc(doc(db, 'menuItems', itemId), { is_active: false, updated_at: new Date().toISOString() }); } catch (e) {}
  const idx = localMenuItems.findIndex((i) => i.menu_item_id === itemId);
  if (idx >= 0) localMenuItems[idx].is_active = false;
  await recordAuditLog({ actor_id: actor.id, actor_name_snapshot: actor.name, actor_role: actor.role, action: 'MENU_ITEM_DEACTIVATED', entity_type: 'menuItem', entity_id: itemId, canteen_id: idx >= 0 ? localMenuItems[idx].canteen_id : null, description: `Deactivated menu item`, before_data: null, after_data: { is_active: false } });
}

export async function addCanteenFirestore(canteen: Canteen, actor: { id: string; name: string; role: string }): Promise<Canteen> {
  try { await setDoc(doc(db, 'canteens', canteen.canteen_id), canteen); } catch (e) {}
  localCanteens.push(canteen);
  await recordAuditLog({ actor_id: actor.id, actor_name_snapshot: actor.name, actor_role: actor.role, action: 'CANTEEN_CREATED', entity_type: 'canteen', entity_id: canteen.canteen_id, canteen_id: canteen.canteen_id, description: `Created canteen`, before_data: null, after_data: canteen as unknown as Record<string, unknown> });
  return canteen;
}

export async function editCanteenFirestore(canteenId: string, updates: Partial<Canteen>, actor: { id: string; name: string; role: string }): Promise<void> {
  const fullUpdates = { ...updates, updated_at: new Date().toISOString() };
  try { await updateDoc(doc(db, 'canteens', canteenId), fullUpdates); } catch (e) {}
  const idx = localCanteens.findIndex((c) => c.canteen_id === canteenId);
  if (idx >= 0) localCanteens[idx] = { ...localCanteens[idx], ...fullUpdates };
  await recordAuditLog({ actor_id: actor.id, actor_name_snapshot: actor.name, actor_role: actor.role, action: 'CANTEEN_UPDATED', entity_type: 'canteen', entity_id: canteenId, canteen_id: canteenId, description: `Updated canteen`, before_data: null, after_data: fullUpdates });
}

export async function deleteCanteenFirestore(canteenId: string, actor: { id: string; name: string; role: string }): Promise<void> {
  try { await updateDoc(doc(db, 'canteens', canteenId), { is_active: false, updated_at: new Date().toISOString() }); } catch (e) {}
  const idx = localCanteens.findIndex((c) => c.canteen_id === canteenId);
  if (idx >= 0) localCanteens[idx].is_active = false;
  await recordAuditLog({ actor_id: actor.id, actor_name_snapshot: actor.name, actor_role: actor.role, action: 'CANTEEN_DEACTIVATED', entity_type: 'canteen', entity_id: canteenId, canteen_id: canteenId, description: `Deactivated canteen`, before_data: null, after_data: { is_active: false } });
}

export async function toggleCanteenStatus(canteenId: string, isOpen: boolean, actor: { id: string; name: string; role: string }): Promise<void> {
  try { await updateDoc(doc(db, 'canteens', canteenId), { is_open: isOpen, updated_at: new Date().toISOString() }); } catch (e) {}
  const idx = localCanteens.findIndex((c) => c.canteen_id === canteenId);
  if (idx >= 0) localCanteens[idx].is_open = isOpen;
  await recordAuditLog({ actor_id: actor.id, actor_name_snapshot: actor.name, actor_role: actor.role, action: isOpen ? 'CANTEEN_OPENED' : 'CANTEEN_CLOSED', entity_type: 'canteen', entity_id: canteenId, canteen_id: canteenId, description: `Canteen was ${isOpen ? 'OPENED' : 'CLOSED'}`, before_data: null, after_data: { is_open: isOpen } });
}

export async function addCategoryFirestore(cat: MenuCategory, actor: { id: string; name: string; role: string }): Promise<void> {
  try { await setDoc(doc(db, 'menuCategories', cat.menu_category_id), cat); } catch (e) {}
  localCategories.push(cat);
  await recordAuditLog({ actor_id: actor.id, actor_name_snapshot: actor.name, actor_role: actor.role, action: 'CATEGORY_CREATED', entity_type: 'category', entity_id: cat.menu_category_id, canteen_id: null, description: `Created category`, before_data: null, after_data: cat as unknown as Record<string, unknown> });
}

export async function updateUserProfileFirestore(userId: string, updates: Partial<UserProfile>, actor: { id: string; name: string; role: string }): Promise<void> {
  const fullUpdates = { ...updates, updated_at: new Date().toISOString() };
  try { await updateDoc(doc(db, 'users', userId), fullUpdates); } catch (e) {}
  await recordAuditLog({ actor_id: actor.id, actor_name_snapshot: actor.name, actor_role: actor.role, action: 'USER_UPDATED', entity_type: 'user', entity_id: userId, canteen_id: null, description: `Updated profile`, before_data: null, after_data: fullUpdates });
}

export async function recordAuditLog(log: Omit<AuditLog, 'audit_log_id' | 'timestamp' | 'source'>): Promise<void> {
  const logId = `log_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
  const fullLog: AuditLog = { ...log, audit_log_id: logId, actor_id: auth.currentUser?.uid || log.actor_id, timestamp: new Date().toISOString(), source: 'client' };
  try { await setDoc(doc(db, 'auditLogs', logId), fullLog); } catch (e) {}
}

export async function fetchAuditLogs(): Promise<AuditLog[]> {
  try {
    const snap = await getDocs(query(collection(db, 'auditLogs'), orderBy('timestamp', 'desc'), limit(50)));
    if (!snap.empty) return snap.docs.map((d) => d.data() as AuditLog);
  } catch (e) {}
  return [];
}

export function listenRevenueForCanteen(canteenId: string, callback: (revenues: Revenue[]) => void): Unsubscribe {
  try {
    const q = query(
      collection(db, 'Revenue'),
      where('canteen_id', '==', canteenId)
    );
    return onSnapshot(q, (snapshot) => {
      if (!snapshot.empty) {
        const revenues = snapshot.docs.map((d) => d.data() as Revenue);
        revenues.sort((a, b) => b.date.localeCompare(a.date));
        localRevenue = revenues;
        callback(revenues);
      } else {
        const q2 = query(collection(db, 'revenue'), where('canteen_id', '==', canteenId));
        getDocs(q2).then((snap) => {
          if (!snap.empty) {
            const list = snap.docs.map((d) => d.data() as Revenue);
            list.sort((a, b) => b.date.localeCompare(a.date));
            callback(list);
          } else {
            const list = localRevenue.filter((r) => r.canteen_id === canteenId);
            list.sort((a, b) => b.date.localeCompare(a.date));
            callback(list);
          }
        }).catch(() => {
          const list = localRevenue.filter((r) => r.canteen_id === canteenId);
          list.sort((a, b) => b.date.localeCompare(a.date));
          callback(list);
        });
      }
    }, (error) => {
      console.warn('Revenue listener fallback:', error.message);
      const list = localRevenue.filter((r) => r.canteen_id === canteenId);
      list.sort((a, b) => b.date.localeCompare(a.date));
      callback(list);
    });
  } catch (err) {
    const list = localRevenue.filter((r) => r.canteen_id === canteenId);
    list.sort((a, b) => b.date.localeCompare(a.date));
    callback(list);
    return () => {};
  }
}

export function listenPaymentHistory(userId: string | null, callback: (payments: PaymentHistory[]) => void): Unsubscribe {
  try {
    const coll = collection(db, 'payments_history');
    const q = userId
      ? query(coll, where('user_id', '==', userId))
      : query(coll, limit(200));
    return onSnapshot(q, (snapshot) => {
      if (!snapshot.empty) {
        const payments = snapshot.docs.map((d) => d.data() as PaymentHistory);
        payments.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
        callback(payments);
      } else {
        const coll2 = collection(db, 'payment_history');
        const q2 = userId
          ? query(coll2, where('user_id', '==', userId))
          : query(coll2, limit(200));
        getDocs(q2).then((snap) => {
          if (!snap.empty) {
            const list = snap.docs.map((d) => d.data() as PaymentHistory);
            list.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());
            callback(list);
          } else {
            const filtered = userId ? localPaymentHistory.filter((p) => p.user_id === userId) : [...localPaymentHistory];
            callback(filtered.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()));
          }
        }).catch(() => {
          const filtered = userId ? localPaymentHistory.filter((p) => p.user_id === userId) : [...localPaymentHistory];
          callback(filtered.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()));
        });
      }
    }, (error) => {
      console.warn('Payment history listener fallback:', error.message);
      const filtered = userId
        ? localPaymentHistory.filter((p) => p.user_id === userId)
        : [...localPaymentHistory];
      callback(filtered.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()));
    });
  } catch (err) {
    const filtered = userId
      ? localPaymentHistory.filter((p) => p.user_id === userId)
      : [...localPaymentHistory];
    callback(filtered.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()));
    return () => {};
  }
}

export async function createNotificationForUser(
  userId: string,
  data: { order_id: string; title: string; body: string; type: import('../models/types').AppNotification['type'] }
): Promise<import('../models/types').AppNotification> {
  const notifId = `notif_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`;
  const notif: import('../models/types').AppNotification = {
    notification_id: notifId,
    user_id: userId,
    order_id: data.order_id,
    title: data.title,
    body: data.body,
    type: data.type,
    is_read: false,
    created_at: new Date().toISOString(),
  };

  try {
    await setDoc(doc(db, 'notifications', notifId), notif);
  } catch (e) {
    console.warn('Failed to save notification to Firestore:', e);
  }

  localNotifications.unshift(notif);

  // Trigger web notification if available in browser
  if (typeof window !== 'undefined' && 'Notification' in window && Notification.permission === 'granted') {
    try {
      new Notification(data.title, { body: data.body, icon: '/favicon.png' });
    } catch (e) {
      // ignore
    }
  }

  return notif;
}

export function listenUserNotifications(
  userId: string,
  callback: (notifs: import('../models/types').AppNotification[]) => void
): Unsubscribe {
  try {
    const q = query(
      collection(db, 'notifications'),
      where('user_id', '==', userId),
      orderBy('created_at', 'desc'),
      limit(50)
    );
    return onSnapshot(
      q,
      (snapshot) => {
        const notifs = snapshot.docs.map((d) => d.data() as import('../models/types').AppNotification);
        callback(notifs);
      },
      (error) => {
        console.warn('User notifications listener fallback:', error.message);
        callback(localNotifications.filter((n) => n.user_id === userId));
      }
    );
  } catch (err) {
    callback(localNotifications.filter((n) => n.user_id === userId));
    return () => {};
  }
}

export async function markNotificationRead(notificationId: string): Promise<void> {
  try {
    await updateDoc(doc(db, 'notifications', notificationId), { is_read: true });
  } catch (e) {
    console.warn('Mark notification read fallback:', e);
  }
  const idx = localNotifications.findIndex((n) => n.notification_id === notificationId);
  if (idx >= 0) localNotifications[idx].is_read = true;
}

export async function markAllNotificationsRead(userId: string): Promise<void> {
  try {
    const q = query(
      collection(db, 'notifications'),
      where('user_id', '==', userId),
      where('is_read', '==', false)
    );
    const snap = await getDocs(q);
    const promises = snap.docs.map((d) => updateDoc(d.ref, { is_read: true }));
    await Promise.all(promises);
  } catch (e) {
    console.warn('Mark all notifications read fallback:', e);
  }
  localNotifications = localNotifications.map((n) =>
    n.user_id === userId ? { ...n, is_read: true } : n
  );
}

export async function getUserNotificationSettings(userId: string): Promise<import('../models/types').NotificationSettings> {
  const defaultSettings: import('../models/types').NotificationSettings = {
    user_id: userId,
    order_placed: true,
    order_accepted: true,
    order_preparing: true,
    order_ready: true,
    pickup_warning: true,
    pickup_failed: true,
    order_declined: true,
  };

  try {
    const snap = await getDoc(doc(db, 'notification_settings', userId));
    if (snap.exists()) {
      return { ...defaultSettings, ...(snap.data() as import('../models/types').NotificationSettings) };
    }
  } catch (e) {
    console.warn('Get notification settings fallback:', e);
  }

  return defaultSettings;
}

export async function updateUserNotificationSettings(
  userId: string,
  settings: import('../models/types').NotificationSettings
): Promise<void> {
  try {
    await setDoc(doc(db, 'notification_settings', userId), settings, { merge: true });
  } catch (e) {
    console.warn('Update notification settings fallback:', e);
  }
}